import java.util.ArrayList;

public class Team {
    private int id;
    private String name;
    private double initialBudget;    // in Crores
    private double remainingBudget;
    private ArrayList<Player> squad;

    public Team(int id, String name, double initialBudget) {
        this.id = id;
        this.name = name;
        this.initialBudget = initialBudget;
        this.remainingBudget = initialBudget;
        this.squad = new ArrayList<>();
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getInitialBudget() { return initialBudget; }
    public double getRemainingBudget() { return remainingBudget; }
    public ArrayList<Player> getSquad() { return squad; }
    public double getTotalSpent() { return initialBudget - remainingBudget; }

    public void addPlayer(Player player, double price) {
        squad.add(player);
        remainingBudget -= price;
    }
}
