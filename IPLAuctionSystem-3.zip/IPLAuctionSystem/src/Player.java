public class Player {
    private int id;
    private String name;
    private String role;
    private double basePrice;      // in Crores
    private boolean sold;
    private double purchasePrice;  // in Crores
    private String teamName;

    public Player(int id, String name, String role, double basePrice) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.basePrice = basePrice;
        this.sold = false;
        this.purchasePrice = 0;
        this.teamName = "-";
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public double getBasePrice() { return basePrice; }
    public boolean isSold() { return sold; }
    public double getPurchasePrice() { return purchasePrice; }
    public String getTeamName() { return teamName; }

    public void markSold(double price, String teamName) {
        this.sold = true;
        this.purchasePrice = price;
        this.teamName = teamName;
    }
}
