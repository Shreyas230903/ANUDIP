import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AuctionManager manager = new AuctionManager(sc);

        System.out.println("=== IPL AUCTION MANAGEMENT SYSTEM ===");
        System.out.println("(Simplified simulation: one winning bid per auction attempt)");

        int choice = 0;
        while (choice != 6) {
            System.out.println("\n----------- MAIN MENU -----------");
            System.out.println("1. View Available Players");
            System.out.println("2. View IPL Teams");
            System.out.println("3. Auction a Player");
            System.out.println("4. View Team Squad");
            System.out.println("5. View Team Budget");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            try {
                choice = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Please enter a number between 1 and 6.");
                choice = 0;
                continue;
            }

            switch (choice) {
                case 1: manager.viewAvailablePlayers(); break;
                case 2: manager.viewTeams(); break;
                case 3: manager.auctionPlayer(); break;
                case 4: manager.viewTeamSquad(); break;
                case 5: manager.viewTeamBudget(); break;
                case 6: System.out.println("Thank you! Exiting..."); break;
                default: System.out.println("Error: Invalid choice. Try again.");
            }
        }
        sc.close();
    }
}
