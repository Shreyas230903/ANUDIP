import java.util.ArrayList;
import java.util.Scanner;

public class AuctionManager {
    private ArrayList<Player> players = new ArrayList<>();
    private ArrayList<Team> teams = new ArrayList<>();
    private Scanner sc;

    public AuctionManager(Scanner sc) {
        this.sc = sc;
        loadSampleData();
    }

    private void loadSampleData() {
        String[] teamNames = {"RCB", "MI", "CSK", "PBKS", "RR", "SRH", "GT", "LSG", "DC", "KKR"};
        for (int i = 0; i < teamNames.length; i++) {
            teams.add(new Team(i + 1, teamNames[i], 100.0));
        }

        players.add(new Player(1, "Virat Kohli", "Batter", 2.0));
        players.add(new Player(2, "Rohit Sharma", "Batter", 2.0));
        players.add(new Player(3, "MS Dhoni", "Wicketkeeper", 2.0));
        players.add(new Player(4, "Jasprit Bumrah", "Bowler", 2.0));
        players.add(new Player(5, "Hardik Pandya", "All-rounder", 2.0));
        players.add(new Player(6, "Ravindra Jadeja", "All-rounder", 1.5));
        players.add(new Player(7, "Shubman Gill", "Batter", 1.5));
        players.add(new Player(8, "Rishabh Pant", "Wicketkeeper", 2.0));
        players.add(new Player(9, "KL Rahul", "Wicketkeeper", 2.0));
        players.add(new Player(10, "Mohammed Siraj", "Bowler", 1.0));
        players.add(new Player(11, "Yuzvendra Chahal", "Bowler", 1.0));
        players.add(new Player(12, "Suryakumar Yadav", "Batter", 2.0));
        players.add(new Player(13, "Sanju Samson", "Wicketkeeper", 1.5));
        players.add(new Player(14, "Axar Patel", "All-rounder", 1.0));
        players.add(new Player(15, "Arshdeep Singh", "Bowler", 1.0));
    }

    // Reads an integer safely; returns -1 if input is not a number
    private int readInt() {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // Reads a decimal safely; returns -1 if input is not a number
    private double readDouble() {
        try {
            return Double.parseDouble(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private Player findPlayer(int id) {
        for (Player p : players) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    private Team findTeam(int id) {
        for (Team t : teams) {
            if (t.getId() == id) return t;
        }
        return null;
    }

    public void viewAvailablePlayers() {
        System.out.println("\n--- Available (Unsold) Players ---");
        System.out.printf("%-4s %-20s %-14s %s%n", "ID", "Name", "Role", "Base Price");
        boolean found = false;
        for (Player p : players) {
            if (!p.isSold()) {
                System.out.printf("%-4d %-20s %-14s %.2f Cr%n",
                        p.getId(), p.getName(), p.getRole(), p.getBasePrice());
                found = true;
            }
        }
        if (!found) System.out.println("All players have been sold.");
    }

    public void viewTeams() {
        System.out.println("\n--- IPL Teams ---");
        for (Team t : teams) {
            System.out.println(t.getId() + ". " + t.getName());
        }
    }

    public void auctionPlayer() {
        viewAvailablePlayers();

        System.out.print("\nEnter Player ID to auction: ");
        int playerId = readInt();
        Player player = findPlayer(playerId);
        if (player == null) {
            System.out.println("Error: Invalid player ID.");
            return;
        }
        if (player.isSold()) {
            System.out.println("Error: " + player.getName() + " is already sold to "
                    + player.getTeamName() + ".");
            return;
        }

        viewTeams();
        System.out.print("\nEnter Team ID: ");
        int teamId = readInt();
        Team team = findTeam(teamId);
        if (team == null) {
            System.out.println("Error: Invalid team ID.");
            return;
        }

        System.out.println("Base price: " + player.getBasePrice() + " Cr | "
                + team.getName() + " remaining budget: " + team.getRemainingBudget() + " Cr");
        System.out.print("Enter bid amount (in Cr): ");
        double bid = readDouble();

        if (bid < 0) {
            System.out.println("Error: Please enter a valid number for the bid.");
        } else if (bid < player.getBasePrice()) {
            System.out.println("Error: Bid is lower than the base price.");
        } else if (bid > team.getRemainingBudget()) {
            System.out.println("Error: Bid exceeds the team's remaining budget.");
        } else {
            player.markSold(bid, team.getName());
            team.addPlayer(player, bid);
            System.out.println("SOLD! " + player.getName() + " goes to " + team.getName()
                    + " for " + bid + " Cr.");
        }
    }

    public void viewTeamSquad() {
        viewTeams();
        System.out.print("\nEnter Team ID: ");
        Team team = findTeam(readInt());
        if (team == null) {
            System.out.println("Error: Invalid team ID.");
            return;
        }
        System.out.println("\n--- " + team.getName() + " Squad ---");
        if (team.getSquad().isEmpty()) {
            System.out.println("No players purchased yet.");
            return;
        }
        for (Player p : team.getSquad()) {
            System.out.printf("%-20s %-14s %.2f Cr%n",
                    p.getName(), p.getRole(), p.getPurchasePrice());
        }
    }

    public void viewTeamBudget() {
        viewTeams();
        System.out.print("\nEnter Team ID: ");
        Team team = findTeam(readInt());
        if (team == null) {
            System.out.println("Error: Invalid team ID.");
            return;
        }
        System.out.println("\n--- " + team.getName() + " Budget ---");
        System.out.println("Initial Budget  : " + team.getInitialBudget() + " Cr");
        System.out.println("Total Spent     : " + team.getTotalSpent() + " Cr");
        System.out.println("Remaining Budget: " + team.getRemainingBudget() + " Cr");
    }
}
