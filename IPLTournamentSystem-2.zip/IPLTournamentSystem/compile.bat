@echo off
if not exist bin mkdir bin
javac -d bin src\ipl\*.java && echo Compiled OK into bin\
