@echo off
rem Runs the application. Optional argument: data folder (default: data)
java -cp bin ipl.Main %*
