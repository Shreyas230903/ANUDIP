#!/bin/sh
mkdir -p bin
javac -d bin src/ipl/*.java && echo "Compiled OK into bin/"
