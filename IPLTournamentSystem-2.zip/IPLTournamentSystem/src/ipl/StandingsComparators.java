package ipl;

import java.util.Comparator;
import java.util.List;

/**
 * Ranking rules for the points table. Each rule is a small Comparator<Team>
 * where "smaller" means "ranked higher". Rules are chained, so the order
 * and the choice of rules can be changed without touching PointsTable.
 *
 * Default order: highest points, then highest NRR, then most wins,
 * then lowest team ID (only so the order is always the same and repeatable).
 */
public class StandingsComparators {

    private StandingsComparators() { }

    /** Higher total points first. */
    public static Comparator<Team> byPoints() {
        return (a, b) -> Integer.compare(b.getTotalPoints(), a.getTotalPoints());
    }

    /**
     * Higher NRR first. NRR is compared as a NUMBER rounded to three decimals
     * (never as text), so two teams that display the same NRR are treated as
     * level and the next rule decides. The table order always agrees with
     * the NRR shown on screen.
     */
    public static Comparator<Team> byNetRunRate() {
        return (a, b) -> Long.compare(
                Math.round(b.getNetRunRate() * 1000.0),
                Math.round(a.getNetRunRate() * 1000.0));
    }

    /** More wins first. */
    public static Comparator<Team> byWins() {
        return (a, b) -> Integer.compare(b.getMatchesWon(), a.getMatchesWon());
    }

    /** Lower team ID first (final tie-breaker). */
    public static Comparator<Team> byTeamId() {
        return Comparator.comparingInt(Team::getId);
    }

    /** The default order: points, NRR, wins, team ID. */
    public static Comparator<Team> defaultOrder() {
        return chain(java.util.Arrays.asList(byPoints(), byNetRunRate(), byWins()));
    }

    /**
     * Builds a comparator that applies the given rules in order, and finally
     * team ID. Use this to configure a different ranking, e.g. wins before NRR:
     * chain(Arrays.asList(byPoints(), byWins(), byNetRunRate())).
     */
    public static Comparator<Team> chain(List<Comparator<Team>> rules) {
        if (rules == null || rules.isEmpty()) {
            throw new IllegalArgumentException("At least one ranking rule is required.");
        }
        Comparator<Team> result = rules.get(0);
        for (int i = 1; i < rules.size(); i++) {
            result = result.thenComparing(rules.get(i));
        }
        return result.thenComparing(byTeamId());
    }
}
