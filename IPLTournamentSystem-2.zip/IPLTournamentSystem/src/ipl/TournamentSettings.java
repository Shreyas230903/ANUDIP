package ipl;

/**
 * Holds every configurable rule of the tournament.
 * Nothing else in the program hard-codes these values.
 *
 * Simplification: no Duckworth-Lewis-Stern (DLS) method is supported.
 */
public class TournamentSettings {

    /** Legal balls in one over. Fixed by the laws of cricket. */
    public static final int BALLS_PER_OVER = 6;

    // ---- Default values ----
    private int pointsForWin = 2;
    private int pointsForLoss = 0;
    private int pointsForTie = 1;
    private int pointsForNoResult = 1;
    private int maxOvers = 20;            // overs per innings
    private int maxWickets = 10;          // wickets that make a team all out
    private boolean doubleRoundRobin = false;  // false = single round robin
    private int qualifiersCount = 4;      // teams that reach the playoffs
    private boolean playoffsEnabled = true;
    private boolean tieBreakInLeague = false;  // false = league ties stay ties

    // ---- Getters ----
    public int getPointsForWin()      { return pointsForWin; }
    public int getPointsForLoss()     { return pointsForLoss; }
    public int getPointsForTie()      { return pointsForTie; }
    public int getPointsForNoResult() { return pointsForNoResult; }
    public int getMaxOvers()          { return maxOvers; }
    public int getMaxWickets()        { return maxWickets; }
    public boolean isDoubleRoundRobin() { return doubleRoundRobin; }
    public int getQualifiersCount()   { return qualifiersCount; }
    public boolean isPlayoffsEnabled() { return playoffsEnabled; }
    public boolean isTieBreakInLeague() { return tieBreakInLeague; }

    /** Total legal balls available in one full innings. */
    public int getMaxBalls() {
        return maxOvers * BALLS_PER_OVER;
    }

    // ---- Setters (with validation) ----
    public void setPointsForWin(int p)      { pointsForWin = checkPoints(p); }
    public void setPointsForLoss(int p)     { pointsForLoss = checkPoints(p); }
    public void setPointsForTie(int p)      { pointsForTie = checkPoints(p); }
    public void setPointsForNoResult(int p) { pointsForNoResult = checkPoints(p); }

    public void setMaxOvers(int overs) {
        if (overs < 1 || overs > 50) {
            throw new IllegalArgumentException("Overs per innings must be between 1 and 50.");
        }
        this.maxOvers = overs;
    }

    public void setMaxWickets(int wickets) {
        if (wickets < 1 || wickets > 10) {
            throw new IllegalArgumentException("Maximum wickets must be between 1 and 10.");
        }
        this.maxWickets = wickets;
    }

    public void setDoubleRoundRobin(boolean doubleRoundRobin) {
        this.doubleRoundRobin = doubleRoundRobin;
    }

    public void setQualifiersCount(int count) {
        if (count < 2 || count > 4) {
            throw new IllegalArgumentException(
                    "Teams qualifying for the playoffs must be 2, 3 or 4 (the supported playoff formats).");
        }
        this.qualifiersCount = count;
    }

    public void setPlayoffsEnabled(boolean playoffsEnabled) {
        this.playoffsEnabled = playoffsEnabled;
    }

    /** If true, a level league match needs a tie-break (e.g. Super Over) winner. */
    public void setTieBreakInLeague(boolean tieBreakInLeague) {
        this.tieBreakInLeague = tieBreakInLeague;
    }

    /** Points must be between 0 and 10. */
    private int checkPoints(int p) {
        if (p < 0 || p > 10) {
            throw new IllegalArgumentException("Points must be between 0 and 10.");
        }
        return p;
    }

    @Override
    public String toString() {
        return "Points: Win=" + pointsForWin + ", Loss=" + pointsForLoss
                + ", Tie=" + pointsForTie + ", No Result=" + pointsForNoResult
                + "\nOvers per innings: " + maxOvers
                + ", Max wickets: " + maxWickets
                + "\nFormat: " + (doubleRoundRobin ? "Double" : "Single") + " round robin"
                + "\nTeams qualifying for playoffs: " + qualifiersCount
                + ", Playoffs enabled: " + playoffsEnabled
                + "\nTie-break in league: " + tieBreakInLeague;
    }
}
