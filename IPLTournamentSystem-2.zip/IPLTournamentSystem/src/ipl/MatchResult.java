package ipl;

/**
 * The outcome of a match. Objects are immutable and created through
 * the factory methods win(), tie() and noResult().
 */
public class MatchResult {

    /** Kind of outcome. */
    public enum Type { WIN, TIE, NO_RESULT }

    /** How the margin of victory is measured. */
    public enum MarginType { RUNS, WICKETS, TIE_BREAK, NONE }

    private final Type type;
    private final Team winner;          // null for TIE and NO_RESULT
    private final int margin;
    private final MarginType marginType;
    private final String description;

    private MatchResult(Type type, Team winner, int margin,
                        MarginType marginType, String description) {
        this.type = type;
        this.winner = winner;
        this.margin = margin;
        this.marginType = marginType;
        this.description = description;
    }

    /** A win by runs, by wickets, or by a tie-break such as a Super Over. */
    public static MatchResult win(Team winner, int margin,
                                  MarginType marginType, String description) {
        if (winner == null) {
            throw new IllegalArgumentException("A winning result needs a winner.");
        }
        return new MatchResult(Type.WIN, winner, margin, marginType, description);
    }

    /** Equal scores in a league match. */
    public static MatchResult tie(String description) {
        return new MatchResult(Type.TIE, null, 0, MarginType.NONE, description);
    }

    /** Abandoned match. No winner is declared. */
    public static MatchResult noResult(String description) {
        return new MatchResult(Type.NO_RESULT, null, 0, MarginType.NONE, description);
    }

    public Type getType()             { return type; }
    public Team getWinner()           { return winner; }
    public int getMargin()            { return margin; }
    public MarginType getMarginType() { return marginType; }
    public String getDescription()    { return description; }

    public boolean hasWinner() {
        return winner != null;
    }

    @Override
    public String toString() {
        return description;
    }
}
