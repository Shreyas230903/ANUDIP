package ipl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * A snapshot of everything Module 10 shows for one team.
 * Built from the points table and the match records, so it can never
 * disagree with them. No console input or output (ReportManager prints it).
 *
 * Definitions used:
 *  - Win percentage = wins / (matches played - no results) x 100 (see Team).
 *  - Completed matches = every finished league match (win, loss, tie or
 *    no result), oldest first. Upcoming matches = still SCHEDULED.
 *  - Longest winning streak: consecutive wins in date order. A loss or a tie
 *    ends the streak. A no-result match is skipped (it neither extends nor
 *    ends the streak). Unplayed matches are ignored.
 *  - Biggest victory is reported in two ways, because runs and wickets
 *    cannot be compared: the largest win by runs (batting first) and the
 *    largest win by wickets (chasing). Tie-break wins are excluded.
 */
public class TeamStatistics {

    private final Team team;
    private final int position;
    private final int totalTeams;
    private final boolean tableHasData;
    private final List<Match> upcomingMatches = new ArrayList<>();
    private final List<Match> completedMatches = new ArrayList<>();
    private int longestWinStreak = 0;
    private Match biggestWinByRuns = null;
    private Match biggestWinByWickets = null;

    public TeamStatistics(Team team, PointsTable pointsTable, MatchManager matchManager) {
        if (team == null) {
            throw new IllegalArgumentException("A team is required.");
        }
        this.team = team;

        List<Team> standings = pointsTable.getStandings();   // also refreshes all statistics
        this.totalTeams = standings.size();
        this.position = standings.indexOf(team) + 1;          // 0 if the team is not registered
        this.tableHasData = pointsTable.hasData();

        List<Match> matches = new ArrayList<>(matchManager.getMatchesForTeam(team));
        matches.sort(Comparator.comparing(Match::getMatchDate)
                .thenComparingInt(Match::getMatchNumber));

        int currentStreak = 0;
        for (Match m : matches) {
            if (!m.isFinished()) {
                upcomingMatches.add(m);
                continue;
            }
            completedMatches.add(m);
            if (m.getStatus() == MatchStatus.NO_RESULT) {
                continue;                                    // skipped for streaks
            }
            if (team.equals(m.getWinner())) {
                currentStreak++;
                longestWinStreak = Math.max(longestWinStreak, currentStreak);
                considerBiggestWin(m);
            } else {
                currentStreak = 0;
            }
        }
    }

    /** Keeps the match with the largest margin, separately for runs and wickets. */
    private void considerBiggestWin(Match m) {
        MatchResult r = m.getResult();
        if (r.getMarginType() == MatchResult.MarginType.RUNS) {
            if (biggestWinByRuns == null
                    || r.getMargin() > biggestWinByRuns.getResult().getMargin()) {
                biggestWinByRuns = m;
            }
        } else if (r.getMarginType() == MatchResult.MarginType.WICKETS) {
            if (biggestWinByWickets == null
                    || r.getMargin() > biggestWinByWickets.getResult().getMargin()) {
                biggestWinByWickets = m;
            }
        }
    }

    public Team getTeam()                  { return team; }
    public int getPosition()               { return position; }
    public int getTotalTeams()             { return totalTeams; }
    public boolean isTableBasedOnResults() { return tableHasData; }
    public int getLongestWinStreak()       { return longestWinStreak; }
    public Match getBiggestWinByRuns()     { return biggestWinByRuns; }
    public Match getBiggestWinByWickets()  { return biggestWinByWickets; }

    public List<Match> getUpcomingMatches() {
        return Collections.unmodifiableList(upcomingMatches);
    }

    public List<Match> getCompletedMatches() {
        return Collections.unmodifiableList(completedMatches);
    }
}
