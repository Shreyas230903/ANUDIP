package ipl;

/**
 * Possible states of a match.
 */
public enum MatchStatus {
    SCHEDULED,   // fixture created, not yet played
    COMPLETED,   // played, with a win or a tie
    NO_RESULT    // abandoned, no winner declared
}
