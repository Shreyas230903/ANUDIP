package ipl;

/**
 * A participating team.
 *
 * Identity data (ID, name, short name, city) is fixed at creation.
 * Season statistics are DERIVED data. The methods that change them have no
 * "public" modifier (package-private), so only classes inside package ipl
 * (mainly PointsTable) can update them. They are always rebuilt from
 * match records, never edited by hand.
 */
public class Team {

    // ---- Identity ----
    private final int id;
    private final String name;
    private final String shortName;
    private final String homeCity;

    // ---- Season statistics (derived) ----
    private int matchesPlayed;
    private int matchesWon;
    private int matchesLost;
    private int matchesTied;
    private int matchesNoResult;
    private int totalPoints;
    private int runsScored;
    private int ballsFaced;       // stored as balls, shown as overs
    private int runsConceded;
    private int ballsBowled;
    private double netRunRate;

    public Team(int id, String name, String shortName, String homeCity) {
        if (id <= 0) {
            throw new IllegalArgumentException("Team ID must be positive.");
        }
        if (isBlank(name) || isBlank(shortName) || isBlank(homeCity)) {
            throw new IllegalArgumentException(
                    "Team name, short name and home city cannot be empty.");
        }
        this.id = id;
        this.name = name.trim();
        this.shortName = shortName.trim().toUpperCase();
        this.homeCity = homeCity.trim();
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    // ---- Public getters ----
    public int getId()               { return id; }
    public String getName()          { return name; }
    public String getShortName()     { return shortName; }
    public String getHomeCity()      { return homeCity; }
    public int getMatchesPlayed()    { return matchesPlayed; }
    public int getMatchesWon()       { return matchesWon; }
    public int getMatchesLost()      { return matchesLost; }
    public int getMatchesTied()      { return matchesTied; }
    public int getMatchesNoResult()  { return matchesNoResult; }
    public int getTotalPoints()      { return totalPoints; }
    public int getRunsScored()       { return runsScored; }
    public int getBallsFaced()       { return ballsFaced; }
    public int getRunsConceded()     { return runsConceded; }
    public int getBallsBowled()      { return ballsBowled; }
    public double getNetRunRate()    { return netRunRate; }

    /** Overs faced in cricket notation, e.g. "59.4". */
    public String getOversFacedText() {
        return Innings.formatOvers(ballsFaced);
    }

    /** Overs bowled in cricket notation. */
    public String getOversBowledText() {
        return Innings.formatOvers(ballsBowled);
    }

    /**
     * Win percentage = Wins / (Matches Played - No Results) x 100.
     * No-result matches are excluded; ties count as played but not as wins.
     * Returns 0 when the denominator is 0, which avoids division by zero.
     */
    public double getWinPercentage() {
        int counted = matchesPlayed - matchesNoResult;
        if (counted <= 0) {
            return 0.0;
        }
        return (matchesWon * 100.0) / counted;
    }

    // ---- Package-private statistic updates (used by PointsTable only) ----

    /** Sets every statistic back to zero before recalculation. */
    void resetStatistics() {
        matchesPlayed = 0;
        matchesWon = 0;
        matchesLost = 0;
        matchesTied = 0;
        matchesNoResult = 0;
        totalPoints = 0;
        runsScored = 0;
        ballsFaced = 0;
        runsConceded = 0;
        ballsBowled = 0;
        netRunRate = 0.0;
    }

    void recordWin(int points) {
        matchesPlayed++;
        matchesWon++;
        totalPoints += points;
    }

    void recordLoss(int points) {
        matchesPlayed++;
        matchesLost++;
        totalPoints += points;
    }

    void recordTie(int points) {
        matchesPlayed++;
        matchesTied++;
        totalPoints += points;
    }

    void recordNoResult(int points) {
        matchesPlayed++;
        matchesNoResult++;
        totalPoints += points;
    }

    /** Adds the runs and balls of one completed match for NRR purposes. */
    void addInningsData(int runsScored, int ballsFaced,
                        int runsConceded, int ballsBowled) {
        this.runsScored += runsScored;
        this.ballsFaced += ballsFaced;
        this.runsConceded += runsConceded;
        this.ballsBowled += ballsBowled;
    }

    void setNetRunRate(double netRunRate) {
        this.netRunRate = netRunRate;
    }

    // ---- Display helpers ----

    /** One-line summary used by "View All Teams". */
    public String toRow() {
        return String.format("%-4d %-28s %-6s %-14s", id, name, shortName, homeCity);
    }

    @Override
    public String toString() {
        return name + " (" + shortName + ")";
    }

    /** Two teams are the same if their IDs match. */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Team)) return false;
        return this.id == ((Team) obj).id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
