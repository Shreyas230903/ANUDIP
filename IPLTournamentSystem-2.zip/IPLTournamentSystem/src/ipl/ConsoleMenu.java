package ipl;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * All console prompts and displays for the 17 menu options.
 * It asks the user for input, calls TournamentManager or the other managers,
 * and prints the outcome. Business rules live in the other classes: when a
 * rule is broken they throw IllegalArgumentException with a clear message,
 * and this class prints that message instead of crashing.
 */
public class ConsoleMenu {

    private final TournamentManager tournament;
    private final TournamentSettings settings;
    private final TeamManager teamManager;
    private final MatchManager matchManager;
    private final PointsTable pointsTable;
    private final PlayoffManager playoffManager;

    /** The values typed in for one match score. */
    private static class ScoreInput {
        int battingFirstId;
        Innings first;
        Innings second;
        int tieBreakWinnerId;      // 0 = none
    }

    public ConsoleMenu(TournamentManager tournament) {
        this.tournament = tournament;
        this.settings = tournament.getSettings();
        this.teamManager = tournament.getTeamManager();
        this.matchManager = tournament.getMatchManager();
        this.pointsTable = tournament.getPointsTable();
        this.playoffManager = tournament.getPlayoffManager();
    }

    // ==================================================================
    // Start-up, main menu, exit
    // ==================================================================

    /** Prints the welcome text and loads saved data, reporting any problems. */
    public void showWelcomeAndLoad() {
        System.out.println("==================================================");
        System.out.println(" IPL-STYLE TOURNAMENT MANAGEMENT SYSTEM (Core Java)");
        System.out.println("==================================================");
        System.out.println("This is a tournament SIMULATION. Its rules and sample data");
        System.out.println("do not represent the official IPL format or records.");
        System.out.println();

        FileManager.LoadResult result = tournament.loadSavedData();
        System.out.println(result.summary());
        if (!result.isFreshStart() && !result.getMissingFiles().isEmpty()) {
            System.out.println("Files not found (treated as empty): " + result.getMissingFiles());
        }
        if (result.hasWarnings()) {
            System.out.println();
            System.out.println(result.getWarnings().size() + " problem(s) found while loading:");
            for (String warning : result.getWarnings()) {
                System.out.println("  - " + warning);
            }
            System.out.println("Bad records were skipped. A copy of each affected file was kept");
            System.out.println("with the extra ending .bad in '" + tournament.getDataDirectory() + "'.");
        }
    }

    public void printMainMenu() {
        System.out.println();
        System.out.println("==================== MAIN MENU ====================");
        System.out.println(" " + tournament.getStatusLine());
        System.out.println("---------------------------------------------------");
        System.out.println("  1. Register a Team");
        System.out.println("  2. View All Teams");
        System.out.println("  3. Search for a Team");
        System.out.println("  4. Create Match Schedule");
        System.out.println("  5. View Match Schedule");
        System.out.println("  6. Enter Match Score");
        System.out.println("  7. View Match Result");
        System.out.println("  8. Update Points Table");
        System.out.println("  9. Display Points Table");
        System.out.println(" 10. Calculate Net Run Rate");
        System.out.println(" 11. Display Top Teams");
        System.out.println(" 12. Display Qualified Teams");
        System.out.println(" 13. Simulate Playoffs");
        System.out.println(" 14. Display Tournament Champion");
        System.out.println(" 15. View Team Statistics");
        System.out.println(" 16. Save Tournament Data");
        System.out.println(" 17. Exit Application");
        System.out.println("===================================================");
    }

    /** Saves and asks to leave. @return true if the application should exit */
    public boolean exitApplication() {
        try {
            tournament.saveData();
            System.out.println("Data saved to '" + tournament.getDataDirectory() + "'. Goodbye.");
            return true;
        } catch (IOException e) {
            System.out.println("ERROR: the data could not be saved (" + describe(e) + ").");
            return InputHelper.readYesNo("Exit WITHOUT saving? Changes since the last save will be lost");
        }
    }

    /** Used when the input stream ends unexpectedly: try to save, then stop. */
    public void saveBeforeStopping() {
        try {
            tournament.saveData();
            System.out.println("Data saved to '" + tournament.getDataDirectory() + "'.");
        } catch (IOException e) {
            System.out.println("ERROR: the data could not be saved (" + describe(e) + ").");
        }
    }

    // ==================================================================
    // 1-3: Teams
    // ==================================================================

    public void registerTeam() {
        System.out.println("\n--- Register a Team ---");
        if (blockedByPlayoffs()) return;
        String name = InputHelper.readNonEmpty("Team name (max " + TeamManager.MAX_NAME_LENGTH + " chars): ");
        String shortName = InputHelper.readNonEmpty("Short name (" + TeamManager.MIN_SHORT_LENGTH + "-"
                + TeamManager.MAX_SHORT_LENGTH + " letters, e.g. MM): ");
        String city = InputHelper.readNonEmpty("Home city (max " + TeamManager.MAX_CITY_LENGTH + " chars): ");
        try {
            Team team = tournament.registerTeam(name, shortName, city);
            System.out.println("Registered: ID " + team.getId() + " - " + team);
        } catch (IllegalArgumentException e) {
            System.out.println("Registration failed: " + e.getMessage());
        }
    }

    public void viewAllTeams() {
        System.out.println("\n--- All Registered Teams ---");
        ReportManager.printTeamList(teamManager.getAllTeams());
    }

    public void searchTeam() {
        System.out.println("\n--- Search for a Team ---");
        String keyword = InputHelper.readNonEmpty("Enter team ID, name or short name: ");
        List<Team> results = teamManager.search(keyword);
        if (results.isEmpty()) {
            System.out.println("No team found for '" + keyword + "'.");
        } else {
            ReportManager.printTeamList(results);
        }
    }

    // ==================================================================
    // 4: Create match schedule (and format settings, new season)
    // ==================================================================

    public void createSchedule() {
        System.out.println("\n--- Create Match Schedule ---");
        System.out.println("Current format: " + (settings.isDoubleRoundRobin() ? "DOUBLE" : "SINGLE")
                + " round robin");
        System.out.println("1. Schedule one match manually");
        System.out.println("2. Generate a round-robin schedule automatically");
        System.out.println("3. Tournament format settings");
        System.out.println("4. Start a NEW season (clears all matches and playoffs, keeps teams)");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 4);
        switch (choice) {
            case 1: scheduleManually(); break;
            case 2: generateSchedule(); break;
            case 3: formatSettings(); break;
            case 4: startNewSeason(); break;
            default: break;
        }
    }

    private void scheduleManually() {
        if (blockedByPlayoffs()) return;
        if (teamManager.getTeamCount() < 2) {
            System.out.println("Register at least 2 teams first (option 1).");
            return;
        }
        ReportManager.printTeamList(teamManager.getAllTeams());
        int homeId = InputHelper.readInt("Home team ID: ", 1, 999999);
        int awayId = InputHelper.readInt("Away team ID: ", 1, 999999);
        LocalDate date = InputHelper.readDate("Match date (yyyy-MM-dd): ");
        String venue = InputHelper.readNonEmpty("Venue (max " + MatchManager.MAX_VENUE_LENGTH + " chars): ");
        try {
            Match m = tournament.scheduleMatch(homeId, awayId, date, venue);
            System.out.println("Scheduled: " + m);
        } catch (IllegalArgumentException e) {
            System.out.println("Scheduling failed: " + e.getMessage());
        }
    }

    private void generateSchedule() {
        if (blockedByPlayoffs()) return;
        if (teamManager.getTeamCount() < 2) {
            System.out.println("Register at least 2 teams first (option 1).");
            return;
        }
        System.out.println("Format: " + (settings.isDoubleRoundRobin()
                ? "DOUBLE round robin (every pair twice, home and away reversed)"
                : "SINGLE round robin (every pair once)"));
        System.out.println("Only missing fixtures are added; existing matches are kept.");
        LocalDate start = InputHelper.readDate("Date of the first match (yyyy-MM-dd): ");
        int gap = InputHelper.readInt("Days between matches (1-30): ", 1, 30);
        try {
            int added = tournament.generateRoundRobin(start, gap);
            System.out.println(added + " match(es) added. Total matches: " + matchManager.getMatchCount());
        } catch (IllegalArgumentException e) {
            System.out.println("Generation failed: " + e.getMessage());
        }
    }

    private void formatSettings() {
        while (true) {
            System.out.println("\n--- Tournament Format Settings ---");
            System.out.println(settings);
            System.out.println("1. Single / double round robin");
            System.out.println("2. Overs per innings");
            System.out.println("3. Maximum wickets (all out)");
            System.out.println("4. Number of teams qualifying for the playoffs (2-4)");
            System.out.println("5. Playoffs on / off");
            System.out.println("6. League tie needs a tie-break winner (on / off)");
            System.out.println("0. Back");
            int choice = InputHelper.readInt("Choice: ", 0, 6);
            if (choice == 0) {
                return;
            }
            try {
                switch (choice) {
                    case 1:
                        tournament.setDoubleRoundRobin(
                                InputHelper.readYesNo("Use DOUBLE round robin? (n = single)"));
                        break;
                    case 2:
                        tournament.setMaxOvers(InputHelper.readInt("Overs per innings (1-50): ", 1, 50));
                        break;
                    case 3:
                        tournament.setMaxWickets(InputHelper.readInt("Maximum wickets (1-10): ", 1, 10));
                        break;
                    case 4:
                        tournament.setQualifiersCount(InputHelper.readInt(
                                "Qualifying teams (2, 3 or 4): ", 2, 4));
                        break;
                    case 5:
                        tournament.setPlayoffsEnabled(InputHelper.readYesNo("Enable the playoffs?"));
                        break;
                    case 6:
                        tournament.setTieBreakInLeague(InputHelper.readYesNo(
                                "Level league matches need a tie-break (Super Over) winner?"));
                        break;
                    default:
                        break;
                }
                System.out.println("Setting updated.");
            } catch (IllegalArgumentException e) {
                System.out.println("Not changed: " + e.getMessage());
            }
        }
    }

    private void startNewSeason() {
        System.out.println("\nThis removes ALL league and playoff matches and zeroes the statistics.");
        System.out.println("Teams and settings are kept. This cannot be undone (unless you exit");
        System.out.println("WITHOUT saving; the files on disk are replaced the next time you save).");
        String answer = InputHelper.readLine("Type NEW SEASON to confirm: ");
        if (!answer.equals("NEW SEASON")) {
            System.out.println("Cancelled. Nothing was changed.");
            return;
        }
        tournament.startNewSeason();
        System.out.println("New season started. " + teamManager.getTeamCount() + " team(s) kept, no matches.");
    }

    // ==================================================================
    // 5: View match schedule
    // ==================================================================

    public void viewSchedule() {
        System.out.println("\n--- View Match Schedule ---");
        System.out.println("1. Full schedule");
        System.out.println("2. Completed and upcoming matches (separately)");
        System.out.println("3. Search by match ID");
        System.out.println("4. Search by team (ID, name or short name)");
        System.out.println("5. Matches of one selected team");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 5);
        switch (choice) {
            case 1:
                System.out.println("\nLeague matches:");
                ReportManager.printMatchList(matchManager.getAllMatches());
                if (playoffManager.hasStarted()) {
                    System.out.println("\nPlayoff matches:");
                    ReportManager.printMatchList(playoffManager.getPlayoffMatches());
                }
                break;
            case 2:
                System.out.println("\nCompleted league matches (including no result):");
                ReportManager.printMatchList(matchManager.getFinishedMatches());
                System.out.println("\nUpcoming league matches:");
                ReportManager.printMatchList(matchManager.getUpcomingMatches());
                break;
            case 3:
                int id = InputHelper.readInt("Match ID (league 1.., playoff " + (PlayoffManager.PLAYOFF_ID_BASE + 1)
                        + "..): ", 1, 999999);
                Match m = findAnyMatch(id);
                if (m == null) {
                    System.out.println("No match with ID " + id + ".");
                } else {
                    List<Match> one = new ArrayList<>();
                    one.add(m);
                    ReportManager.printMatchList(one);
                }
                break;
            case 4:
                String keyword = InputHelper.readNonEmpty("Team ID, name or short name: ");
                ReportManager.printMatchList(matchManager.findByTeamKeyword(keyword));
                break;
            case 5:
                Team team = selectTeam();
                if (team != null) {
                    System.out.println("\nMatches of " + team + ":");
                    ReportManager.printMatchList(matchManager.getMatchesForTeam(team));
                }
                break;
            default:
                break;
        }
    }

    // ==================================================================
    // 6: Enter match score (league matches)
    // ==================================================================

    public void enterMatchScore() {
        System.out.println("\n--- Enter Match Score (league matches) ---");
        System.out.println("1. Enter the score of an upcoming match");
        System.out.println("2. Mark an upcoming match as 'no result'");
        System.out.println("3. Correct a finished match");
        System.out.println("0. Back");
        System.out.println("(Playoff scores are entered in option 13.)");
        int choice = InputHelper.readInt("Choice: ", 0, 3);
        if (choice == 0) return;
        if (blockedByPlayoffs()) return;
        switch (choice) {
            case 1: enterScoreFlow(); break;
            case 2: noResultFlow(); break;
            case 3: correctionFlow(); break;
            default: break;
        }
    }

    private void enterScoreFlow() {
        List<Match> upcoming = matchManager.getUpcomingMatches();
        if (upcoming.isEmpty()) {
            System.out.println("There are no upcoming matches. Create a schedule first (option 4).");
            return;
        }
        ReportManager.printMatchList(upcoming);
        int matchId = InputHelper.readInt("Match ID (0 to cancel): ", 0, 999999);
        if (matchId == 0) return;
        Match match = matchManager.findById(matchId);
        if (match == null) {
            System.out.println("No league match with ID " + matchId + ".");
            return;
        }
        if (match.isFinished()) {
            System.out.println("Match " + match.getMatchNumber() + " already has a result ("
                    + match.getResultDescription() + "). It cannot be overwritten here; "
                    + "use 'Correct a finished match'.");
            return;
        }
        ScoreInput in = readScoreInput(match, false);
        try {
            Match saved = tournament.enterScore(matchId, in.battingFirstId, in.first, in.second,
                    in.tieBreakWinnerId);
            System.out.println("\nSaved. The points table will use this result.\n");
            ReportManager.printMatchResult(saved);
        } catch (IllegalArgumentException e) {
            System.out.println("Not saved: " + e.getMessage());
        }
    }

    private void noResultFlow() {
        List<Match> upcoming = matchManager.getUpcomingMatches();
        if (upcoming.isEmpty()) {
            System.out.println("There are no upcoming matches.");
            return;
        }
        ReportManager.printMatchList(upcoming);
        int matchId = InputHelper.readInt("Match ID (0 to cancel): ", 0, 999999);
        if (matchId == 0) return;
        try {
            Match m = tournament.enterNoResult(matchId);
            System.out.println("Saved. Match " + m.getMatchNumber() + ": " + m.getResultDescription());
        } catch (IllegalArgumentException e) {
            System.out.println("Not saved: " + e.getMessage());
        }
    }

    private void correctionFlow() {
        List<Match> finished = matchManager.getFinishedMatches();
        if (finished.isEmpty()) {
            System.out.println("No finished matches to correct.");
            return;
        }
        ReportManager.printMatchList(finished);
        int matchId = InputHelper.readInt("Match ID to correct (0 to cancel): ", 0, 999999);
        if (matchId == 0) return;
        Match match = matchManager.findById(matchId);
        if (match == null || !match.isFinished()) {
            System.out.println("Match " + matchId + " is not a finished league match.");
            return;
        }
        System.out.println("\nCurrent record:");
        ReportManager.printMatchResult(match);
        System.out.println("\n1. Replace with new scores");
        System.out.println("2. Change to 'no result'");
        System.out.println("3. Remove the result (back to scheduled)");
        System.out.println("0. Cancel");
        int choice = InputHelper.readInt("Choice: ", 0, 3);
        if (choice == 0) return;

        ScoreInput in = null;
        if (choice == 1) {
            in = readScoreInput(match, false);
        }
        if (!InputHelper.readYesNo("A correction REPLACES the saved result and changes the points table. Continue?")) {
            System.out.println("Correction cancelled. Nothing was changed.");
            return;
        }
        try {
            Match m;
            if (choice == 1) {
                m = tournament.correctScore(matchId, in.battingFirstId, in.first, in.second,
                        in.tieBreakWinnerId);
            } else if (choice == 2) {
                m = tournament.correctToNoResult(matchId);
            } else {
                m = tournament.reopenMatch(matchId);
            }
            System.out.println("\nCorrection saved. The points table is recalculated from the match "
                    + "records, so nothing is counted twice.\n");
            ReportManager.printMatchResult(m);
        } catch (IllegalArgumentException e) {
            System.out.println("Not saved: " + e.getMessage() + " The previous result is unchanged.");
        }
    }

    /** Asks for who batted first and both innings. Used for league and playoff matches. */
    private ScoreInput readScoreInput(Match match, boolean playoff) {
        Team home = match.getHomeTeam();
        Team away = match.getAwayTeam();
        String label = playoff ? match.getStage().getLabel()
                : match.getStage().getLabel() + " " + match.getMatchNumber();
        System.out.println("\n" + label + ": "
                + home.getName() + " (home) vs " + away.getName() + " (away)");
        System.out.println("1. " + home.getName() + "   2. " + away.getName());
        int who = InputHelper.readInt("Which team batted first (1 or 2): ", 1, 2);
        Team batFirst = (who == 1) ? home : away;
        Team batSecond = (who == 1) ? away : home;

        System.out.println("Enter overs as completed overs + extra balls (19.4 overs = 19 overs and 4 balls).");
        ScoreInput in = new ScoreInput();
        in.battingFirstId = batFirst.getId();
        in.first = readInnings("First innings - " + batFirst.getName());
        in.second = readInnings("Second innings - " + batSecond.getName());

        boolean level = in.first.getRuns() == in.second.getRuns();
        if (level && (playoff || settings.isTieBreakInLeague())) {
            System.out.println("The scores are level and this match needs a winner.");
            System.out.println("1. " + home.getName() + "   2. " + away.getName());
            int winner = InputHelper.readInt("Tie-break (Super Over) winner (1 or 2): ", 1, 2);
            in.tieBreakWinnerId = (winner == 1) ? home.getId() : away.getId();
        }
        return in;
    }

    private Innings readInnings(String label) {
        System.out.println(label);
        int runs = InputHelper.readInt("  Runs scored: ", 0, 999);
        int wickets = InputHelper.readInt("  Wickets lost (0-" + settings.getMaxWickets() + "): ",
                0, settings.getMaxWickets());
        int overs = InputHelper.readInt("  Completed overs (0-" + settings.getMaxOvers() + "): ",
                0, settings.getMaxOvers());
        int balls = InputHelper.readInt("  Extra balls in the next over (0-"
                + (TournamentSettings.BALLS_PER_OVER - 1) + "): ",
                0, TournamentSettings.BALLS_PER_OVER - 1);
        return new Innings(runs, wickets, Innings.toBalls(overs, balls));
    }

    // ==================================================================
    // 7: View match result
    // ==================================================================

    public void viewMatchResult() {
        System.out.println("\n--- View Match Result ---");
        System.out.println("1. Result of one match (by match ID)");
        System.out.println("2. All completed league matches");
        System.out.println("3. Corrections made in this session");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 3);
        switch (choice) {
            case 1:
                if (matchManager.getMatchCount() == 0 && !playoffManager.hasStarted()) {
                    System.out.println("There are no matches yet.");
                    break;
                }
                int id = InputHelper.readInt("Match ID (league 1.., playoff "
                        + (PlayoffManager.PLAYOFF_ID_BASE + 1) + "..): ", 1, 999999);
                Match m = findAnyMatch(id);
                if (m == null) {
                    System.out.println("No match with ID " + id + ".");
                } else {
                    System.out.println();
                    ReportManager.printMatchResult(m);
                }
                break;
            case 2:
                System.out.println();
                ReportManager.printCompletedResults(matchManager.getFinishedMatches());
                break;
            case 3:
                if (matchManager.getCorrectionLog().isEmpty()) {
                    System.out.println("No corrections have been made in this session.");
                }
                for (String entry : matchManager.getCorrectionLog()) {
                    System.out.println(entry);
                }
                break;
            default:
                break;
        }
    }

    // ==================================================================
    // 8-11: Points table, NRR, top teams
    // ==================================================================

    public void updatePointsTable() {
        System.out.println("\n--- Update Points Table ---");
        System.out.println("The table is always rebuilt from the match records, so it is");
        System.out.println("never out of date. 'Update' recalculates it now and shows it.");
        System.out.println("1. Recalculate and show the points table");
        System.out.println("2. Change the points system (win / loss / tie / no result)");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 2);
        if (choice == 1) {
            pointsTable.recalculate();
            System.out.println("Recalculated from " + pointsTable.getMatchesCounted()
                    + " finished league match(es).\n");
            ReportManager.printPointsTable(pointsTable.getStandings(), pointsTable.getMatchesCounted());
        } else if (choice == 2) {
            changePointsSystem();
        }
    }

    private void changePointsSystem() {
        if (blockedByPlayoffs()) return;
        System.out.println("Current points: win " + settings.getPointsForWin()
                + ", loss " + settings.getPointsForLoss()
                + ", tie " + settings.getPointsForTie()
                + ", no result " + settings.getPointsForNoResult());
        int win = InputHelper.readInt("Points for a win (0-10): ", 0, 10);
        int loss = InputHelper.readInt("Points for a loss (0-10): ", 0, 10);
        int tie = InputHelper.readInt("Points for a tie, per team (0-10): ", 0, 10);
        int noResult = InputHelper.readInt("Points for no result, per team (0-10): ", 0, 10);
        if (!InputHelper.readYesNo("Apply these points to the whole table?")) {
            System.out.println("Cancelled. Nothing was changed.");
            return;
        }
        try {
            tournament.setPoints(win, loss, tie, noResult);
            System.out.println("Points system updated.\n");
            ReportManager.printPointsTable(pointsTable.getStandings(), pointsTable.getMatchesCounted());
        } catch (IllegalArgumentException e) {
            System.out.println("Not changed: " + e.getMessage());
        }
    }

    public void displayPointsTable() {
        System.out.println("\n--- Points Table (league stage) ---");
        ReportManager.printPointsTable(pointsTable.getStandings(), pointsTable.getMatchesCounted());
        System.out.println("Playoff results are kept separately and do not change this table.");
    }

    public void calculateNetRunRate() {
        System.out.println("\n--- Net Run Rate ---");
        System.out.println("NRR = (runs scored / overs faced) - (runs conceded / overs bowled)");
        System.out.println("Overs are converted to balls / 6, and an all-out innings counts the");
        System.out.println("full " + settings.getMaxOvers() + " overs. No-result matches are ignored.\n");
        List<Team> standings = pointsTable.getStandings();
        ReportManager.printNetRunRateDetails(standings);
        if (!pointsTable.hasData()) {
            System.out.println("No league match has been completed yet, so every NRR is 0.000.");
        }
    }

    public void displayTopTeams() {
        System.out.println("\n--- Top Teams ---");
        if (teamManager.isEmpty()) {
            System.out.println("No teams registered.");
            return;
        }
        List<Team> standings = pointsTable.getStandings();
        if (!pointsTable.hasData()) {
            System.out.println("No league match has been completed yet, so there are no top teams.");
            return;
        }
        int defaultCount = Math.min(settings.getQualifiersCount(), standings.size());
        int count = InputHelper.readInt("How many top teams to show (1-" + standings.size()
                + ", " + defaultCount + " qualify): ", 1, standings.size());
        ReportManager.printPointsTable(new ArrayList<>(standings.subList(0, count)),
                pointsTable.getMatchesCounted());
    }

    // ==================================================================
    // 12: Qualified teams
    // ==================================================================

    public void displayQualifiedTeams() {
        System.out.println("\n--- Qualified Teams ---");
        System.out.println("Format: " + PlayoffManager.describeFormat(settings.getQualifiersCount()));
        if (!settings.isPlayoffsEnabled()) {
            System.out.println("Note: playoffs are switched off in the settings.");
        }
        List<Team> qualified = playoffManager.getQualifiedTeams();
        List<Team> others = playoffManager.getNonQualifiedTeams();
        ReportManager.printQualification(qualified, others, matchManager.getUpcomingMatches().size());
        String warning = playoffManager.getCutoffWarning();
        if (warning != null) {
            System.out.println("\n" + warning);
        }
        if (playoffManager.hasStarted()) {
            System.out.println("\nThe playoffs have started; the qualified teams are now fixed by the fixtures.");
        }
    }

    // ==================================================================
    // 13: Simulate playoffs
    // ==================================================================

    public void simulatePlayoffs() {
        System.out.println("\n--- Simulate Playoffs ---");
        if (playoffManager.hasStarted()) {
            playoffMenuWhenStarted();
            return;
        }
        startPlayoffsFlow();
        if (playoffManager.hasStarted()) {
            enterPlayoffResults();
        }
    }

    private void startPlayoffsFlow() {
        boolean authoriseIncomplete = false;
        String problem = playoffManager.checkCanStart(false);
        if (problem != null) {
            if (playoffManager.checkCanStart(true) != null) {
                System.out.println("The playoffs cannot start: " + problem);
                return;
            }
            // Only the unfinished league blocks the start: the administrator may authorise it
            System.out.println(problem);
            if (!InputHelper.readYesNo("Authorise an INCOMPLETE-season playoff simulation")) {
                System.out.println("Cancelled. The playoffs were not started.");
                return;
            }
            authoriseIncomplete = true;
        }

        System.out.println("\nFormat: " + PlayoffManager.describeFormat(settings.getQualifiersCount()));
        ReportManager.printQualification(playoffManager.getQualifiedTeams(),
                playoffManager.getNonQualifiedTeams(), matchManager.getUpcomingMatches().size());
        String warning = playoffManager.getCutoffWarning();
        if (warning != null) {
            System.out.println("\n" + warning);
        }

        LocalDate suggested = playoffManager.suggestStartDate();
        LocalDate start = readDateWithDefault("\nDate of the first playoff match (yyyy-MM-dd) ["
                + suggested + "]: ", suggested);
        System.out.println("Once created, the playoff fixtures cannot be created a second time, and");
        System.out.println("league data becomes locked.");
        if (!InputHelper.readYesNo("Create the playoff fixtures now")) {
            System.out.println("Cancelled. The playoffs were not started.");
            return;
        }
        try {
            playoffManager.startPlayoffs(start, authoriseIncomplete);
            System.out.println("\nPlayoff fixtures created:");
            ReportManager.printMatchList(playoffManager.getPlayoffMatches());
        } catch (IllegalArgumentException e) {
            System.out.println("The playoffs were not started: " + e.getMessage());
        }
    }

    /** Enters the pending playoff results one after another; the user may stop and resume later. */
    private void enterPlayoffResults() {
        while (true) {
            Match next = playoffManager.getNextPendingMatch();
            if (next == null) {
                break;
            }
            System.out.println("\nNext: " + next.getStage() + " - " + next.getHomeTeam().getName()
                    + " vs " + next.getAwayTeam().getName() + " on " + next.getMatchDate());
            if (!InputHelper.readYesNo("Enter the result of the " + next.getStage() + " now")) {
                System.out.println("You can continue later with option 13. Progress is saved with option 16.");
                return;
            }
            ScoreInput in = readScoreInput(next, true);
            try {
                Match saved = playoffManager.enterScore(next.getMatchId(), in.battingFirstId,
                        in.first, in.second, in.tieBreakWinnerId);
                System.out.println("\nSaved.\n");
                ReportManager.printMatchResult(saved);
            } catch (IllegalArgumentException e) {
                System.out.println("Not saved: " + e.getMessage());
            }
        }
        if (playoffManager.isFinished()) {
            System.out.println();
            ReportManager.printPlayoffResults(playoffManager.getPlayoffMatches());
            System.out.println();
            ReportManager.printChampion(playoffManager.getChampion());
            System.out.println("Runner-up: " + playoffManager.getRunnerUp().getName());
        }
    }

    private void playoffMenuWhenStarted() {
        System.out.println("The playoffs have already been created. They cannot be simulated a second time.");
        System.out.println();
        ReportManager.printPlayoffResults(playoffManager.getPlayoffMatches());
        System.out.println();
        System.out.println("1. Enter the next playoff result");
        System.out.println("2. Reset the playoffs (deletes ALL playoff matches; league results are kept)");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 2);
        if (choice == 1) {
            if (playoffManager.getNextPendingMatch() == null) {
                System.out.println("All playoff matches are complete.");
                ReportManager.printChampion(playoffManager.getChampion());
            } else {
                enterPlayoffResults();
            }
        } else if (choice == 2) {
            String answer = InputHelper.readLine("Type RESET PLAYOFFS to confirm: ");
            if (answer.equals("RESET PLAYOFFS")) {
                int removed = playoffManager.resetPlayoffs();
                System.out.println(removed + " playoff match(es) deleted. League data is unlocked.");
            } else {
                System.out.println("Cancelled. Nothing was changed.");
            }
        }
    }

    // ==================================================================
    // 14: Champion and full report
    // ==================================================================

    public void displayChampion() {
        System.out.println("\n--- Tournament Champion ---");
        System.out.println("1. Show the champion");
        System.out.println("2. Full tournament report (all 12 sections)");
        System.out.println("0. Back");
        int choice = InputHelper.readInt("Choice: ", 0, 2);
        if (choice == 1) {
            System.out.println();
            ReportManager.printLeagueLeader(pointsTable.getStandings(), pointsTable.getMatchesCounted(),
                    matchManager.getUpcomingMatches().size());
            System.out.println();
            ReportManager.printPlayoffResults(playoffManager.getPlayoffMatches());
            System.out.println();
            ReportManager.printChampion(playoffManager.getChampion());
        } else if (choice == 2) {
            fullReport();
        }
    }

    private void fullReport() {
        List<Team> standings = pointsTable.getStandings();
        int counted = pointsTable.getMatchesCounted();
        int remaining = matchManager.getUpcomingMatches().size();

        System.out.println("\n########## TOURNAMENT REPORT (simulation) ##########");
        section("1", "Complete team list");
        ReportManager.printTeamList(teamManager.getAllTeams());
        section("2", "Complete match schedule");
        ReportManager.printMatchList(matchManager.getAllMatches());
        if (playoffManager.hasStarted()) {
            System.out.println("\nPlayoff matches:");
            ReportManager.printMatchList(playoffManager.getPlayoffMatches());
        }
        section("3", "Completed match results");
        ReportManager.printCompletedResults(matchManager.getFinishedMatches());
        section("4", "Current points table");
        ReportManager.printPointsTable(standings, counted);
        section("5", "Highest-ranked team (league stage)");
        ReportManager.printLeagueLeader(standings, counted, remaining);
        section("6-7", "Teams qualified for the playoffs and teams eliminated");
        ReportManager.printQualification(playoffManager.getQualifiedTeams(),
                playoffManager.getNonQualifiedTeams(), remaining);
        section("8", "Team-wise win percentage");
        ReportManager.printWinPercentages(standings);
        section("9", "Highest-scoring team");
        ReportManager.printHighestScoring(standings);
        section("10", "Best net run rate");
        ReportManager.printBestNrr(standings, pointsTable.hasData());
        section("11", "Playoff results");
        ReportManager.printPlayoffResults(playoffManager.getPlayoffMatches());
        section("12", "Tournament champion");
        ReportManager.printChampion(playoffManager.getChampion());
        System.out.println("\n########## END OF REPORT ##########");
    }

    private void section(String number, String title) {
        System.out.println("\n[" + number + "] " + title.toUpperCase());
        System.out.println(ReportManager.line(60));
    }

    // ==================================================================
    // 15-16: Team statistics, save
    // ==================================================================

    public void viewTeamStatistics() {
        System.out.println("\n--- Team Statistics ---");
        Team team = selectTeam();
        if (team == null) return;
        System.out.println();
        ReportManager.printTeamStatistics(new TeamStatistics(team, pointsTable, matchManager));
    }

    public void saveData() {
        System.out.println("\n--- Save Tournament Data ---");
        try {
            tournament.saveData();
            System.out.println("Saved to the folder '" + tournament.getDataDirectory() + "'.");
        } catch (IOException e) {
            System.out.println("ERROR: the data could not be saved (" + describe(e) + ").");
            System.out.println("Your earlier saved files were not changed.");
        }
    }

    // ==================================================================
    // Helpers
    // ==================================================================

    /** "FileSystemException: reason", so the error type is visible, not only a path. */
    private static String describe(IOException e) {
        return e.getClass().getSimpleName() + ": " + e.getMessage();
    }

    /** Prints a message and returns true when the playoffs lock league data. */
    private boolean blockedByPlayoffs() {
        if (tournament.isLeagueLocked()) {
            System.out.println("Not possible: the playoffs have started, so league data is locked.");
            System.out.println("Reset the playoffs first (option 13) if you really must change it.");
            return true;
        }
        return false;
    }

    /** Finds a league match, or failing that a playoff match, by ID. */
    private Match findAnyMatch(int id) {
        Match m = matchManager.findById(id);
        return (m != null) ? m : playoffManager.findById(id);
    }

    /** Asks for a team by ID, name or short name. @return the team, or null if none was chosen */
    private Team selectTeam() {
        if (teamManager.isEmpty()) {
            System.out.println("No teams registered yet.");
            return null;
        }
        String keyword = InputHelper.readNonEmpty("Enter team ID, name or short name: ");
        List<Team> found = teamManager.search(keyword);
        if (found.isEmpty()) {
            System.out.println("No team found for '" + keyword + "'.");
            return null;
        }
        if (found.size() == 1) {
            return found.get(0);
        }
        System.out.println("Several teams match:");
        ReportManager.printTeamList(found);
        int id = InputHelper.readInt("Enter the ID of the team you want: ", 1, 999999);
        for (Team t : found) {
            if (t.getId() == id) {
                return t;
            }
        }
        System.out.println("ID " + id + " is not in the list above.");
        return null;
    }

    /** Reads a date; pressing Enter accepts the default. */
    private LocalDate readDateWithDefault(String prompt, LocalDate defaultDate) {
        while (true) {
            String text = InputHelper.readLine(prompt);
            if (text.isEmpty() && defaultDate != null) {
                return defaultDate;
            }
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException e) {
                System.out.println("Error: use the format yyyy-MM-dd (e.g. 2026-04-15).");
            }
        }
    }
}
