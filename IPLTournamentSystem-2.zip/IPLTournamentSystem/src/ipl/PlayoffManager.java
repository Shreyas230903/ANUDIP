package ipl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Playoff qualification and progression (Module 9).
 *
 * Playoff matches are kept in their OWN list, separate from the league
 * schedule in MatchManager, so they can never change the points table.
 *
 * Supported formats (set by TournamentSettings.qualifiersCount):
 *  4 teams: Qualifier 1 (rank 1 v 2), Eliminator (rank 3 v 4),
 *           Qualifier 2 (loser of Q1 v winner of Eliminator),
 *           Final (winner of Q1 v winner of Q2).
 *  3 teams: Eliminator (rank 2 v 3), Final (rank 1 v winner of Eliminator).
 *  2 teams: Final (rank 1 v 2).
 *
 * Rules:
 *  - Playoffs start only when the league stage is complete, or when the
 *    administrator explicitly authorises an incomplete-season simulation.
 *  - Playoffs can be started once. A second start is refused.
 *  - Later stages are created automatically when their feeder matches finish.
 *  - A playoff match must produce a winner: a tie needs a tie-break
 *    (Super Over) winner, and "no result" is not supported.
 *  - A playoff result cannot be overwritten. The only way to redo playoffs is
 *    the explicit resetPlayoffs(). The caller (TournamentManager, Step 10) must
 *    also block league score changes once playoffs have started, because
 *    that could change who qualified.
 */
public class PlayoffManager {

    /** Playoff match IDs start here so they never clash with league match IDs. */
    public static final int PLAYOFF_ID_BASE = 10000;
    public static final int MIN_QUALIFIERS = 2;
    public static final int MAX_QUALIFIERS = 4;

    private final TeamManager teamManager;
    private final MatchManager matchManager;
    private final PointsTable pointsTable;
    private final TournamentSettings settings;
    private final List<Match> playoffMatches = new ArrayList<>();   // kept in stage order

    public PlayoffManager(TeamManager teamManager, MatchManager matchManager,
                          PointsTable pointsTable, TournamentSettings settings) {
        this.teamManager = teamManager;
        this.matchManager = matchManager;
        this.pointsTable = pointsTable;
        this.settings = settings;
    }

    // ------------------------------------------------------------------
    // Qualification
    // ------------------------------------------------------------------

    /**
     * The teams currently in a qualifying position, rank 1 first.
     * Empty when no league match has been completed (no ranking exists yet).
     */
    public List<Team> getQualifiedTeams() {
        List<Team> standings = pointsTable.getStandings();
        if (!pointsTable.hasData()) {
            return new ArrayList<>();
        }
        int n = Math.min(settings.getQualifiersCount(), standings.size());
        return new ArrayList<>(standings.subList(0, n));
    }

    /** The teams currently outside the qualifying positions, in rank order. */
    public List<Team> getNonQualifiedTeams() {
        List<Team> standings = pointsTable.getStandings();
        if (!pointsTable.hasData()) {
            return new ArrayList<>();
        }
        int n = Math.min(settings.getQualifiersCount(), standings.size());
        return new ArrayList<>(standings.subList(n, standings.size()));
    }

    /**
     * @return a warning if the last qualifying team and the first team outside
     *         are level on points, NRR and wins (so team ID decided the place);
     *         otherwise null
     */
    public String getCutoffWarning() {
        List<Team> standings = pointsTable.getStandings();
        int n = settings.getQualifiersCount();
        if (!pointsTable.hasData() || standings.size() <= n) {
            return null;
        }
        Team last = standings.get(n - 1);
        Team next = standings.get(n);
        boolean level = last.getTotalPoints() == next.getTotalPoints()
                && last.getMatchesWon() == next.getMatchesWon()
                && Math.round(last.getNetRunRate() * 1000.0)
                        == Math.round(next.getNetRunRate() * 1000.0);
        if (level) {
            return "Warning: " + last.getName() + " and " + next.getName()
                    + " are level on points, NRR and wins at the qualification cut-off; "
                    + "the place is decided by team ID only.";
        }
        return null;
    }

    /** Text describing the playoff format for a number of qualifying teams. */
    public static String describeFormat(int teams) {
        switch (teams) {
            case 4:  return "4 teams: Qualifier 1 (1v2), Eliminator (3v4), "
                           + "Qualifier 2 (loser Q1 v winner Eliminator), Final";
            case 3:  return "3 teams: Eliminator (2v3), Final (rank 1 v winner Eliminator)";
            case 2:  return "2 teams: Final (1v2)";
            default: return teams + " teams: not supported";
        }
    }

    // ------------------------------------------------------------------
    // Starting the playoffs
    // ------------------------------------------------------------------

    /**
     * Checks whether the playoffs may start now.
     * @param allowIncompleteLeague true only if the administrator has explicitly
     *                              authorised an incomplete-season simulation
     * @return null if the playoffs can start, otherwise the reason they cannot
     */
    public String checkCanStart(boolean allowIncompleteLeague) {
        if (!settings.isPlayoffsEnabled()) {
            return "Playoffs are switched off in the tournament settings.";
        }
        if (hasStarted()) {
            return "The playoffs have already been started. They cannot be simulated twice; "
                    + "an administrator must reset them explicitly first.";
        }
        int q = settings.getQualifiersCount();
        if (q < MIN_QUALIFIERS || q > MAX_QUALIFIERS) {
            return "The playoff format supports 2, 3 or 4 qualifying teams, not " + q + ".";
        }
        if (teamManager.getTeamCount() < q) {
            return "At least " + q + " registered teams are needed for a " + q + "-team playoff.";
        }
        if (matchManager.getMatchCount() == 0) {
            return "There is no league schedule yet.";
        }
        pointsTable.recalculate();
        if (!pointsTable.hasData()) {
            return "No league match has been completed, so qualification cannot be decided.";
        }
        int remaining = matchManager.getUpcomingMatches().size();
        if (remaining > 0 && !allowIncompleteLeague) {
            return "The league stage is not complete (" + remaining + " match(es) still to be "
                    + "played). An administrator must explicitly authorise an "
                    + "incomplete-season simulation to continue.";
        }
        return null;
    }

    /** Date after the last league match, a sensible start date; null if there are no matches. */
    public LocalDate suggestStartDate() {
        LocalDate last = lastLeagueDate();
        return (last == null) ? null : last.plusDays(1);
    }

    private LocalDate lastLeagueDate() {
        LocalDate last = null;
        for (Match m : matchManager.getAllMatches()) {
            if (last == null || m.getMatchDate().isAfter(last)) {
                last = m.getMatchDate();
            }
        }
        return last;
    }

    /**
     * Creates the first playoff stage from the current standings.
     * Later stages are created by enterScore() as results come in.
     *
     * @param startDate              date of the first playoff match (after the last league match)
     * @param allowIncompleteLeague  explicit administrator authorisation, see checkCanStart()
     * @return the playoff matches created now
     * @throws IllegalArgumentException if the playoffs cannot start
     */
    public List<Match> startPlayoffs(LocalDate startDate, boolean allowIncompleteLeague) {
        String problem = checkCanStart(allowIncompleteLeague);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }
        if (startDate == null) {
            throw new IllegalArgumentException("A playoff start date is required.");
        }
        LocalDate last = lastLeagueDate();
        if (last != null && !startDate.isAfter(last)) {
            throw new IllegalArgumentException(
                    "Playoffs must start after the last league match date (" + last + ").");
        }

        List<Team> seeds = getQualifiedTeams();    // exactly 'qualifiersCount' teams, rank order
        switch (seeds.size()) {
            case 4:
                addMatch(seeds.get(0), seeds.get(1), MatchStage.QUALIFIER_1, startDate);
                addMatch(seeds.get(2), seeds.get(3), MatchStage.ELIMINATOR, startDate.plusDays(1));
                break;
            case 3:
                addMatch(seeds.get(1), seeds.get(2), MatchStage.ELIMINATOR, startDate);
                break;
            default:
                addMatch(seeds.get(0), seeds.get(1), MatchStage.FINAL, startDate);
                break;
        }
        return new ArrayList<>(playoffMatches);
    }

    private Match addMatch(Team home, Team away, MatchStage stage, LocalDate date) {
        int number = playoffMatches.size() + 1;
        Match match = new Match(PLAYOFF_ID_BASE + number, number, home, away, date,
                home.getHomeCity() + " Stadium", stage);
        playoffMatches.add(match);
        playoffMatches.sort(Comparator.comparingInt((Match m) -> m.getStage().ordinal()));
        return match;
    }

    // ------------------------------------------------------------------
    // Entering results and progressing
    // ------------------------------------------------------------------

    /**
     * Enters the scores of a SCHEDULED playoff match. A playoff match must have
     * a winner, so a tie needs a tie-break winner. When the result completes a
     * stage, the next stage is created automatically.
     *
     * @param tieBreakWinnerId tie-break winner's team ID, or 0 if scores are not level
     */
    public Match enterScore(int playoffMatchId, int battingFirstTeamId, Innings first,
                            Innings second, int tieBreakWinnerId) {
        Match match = findById(playoffMatchId);
        if (match == null) {
            throw new IllegalArgumentException("No playoff match with ID " + playoffMatchId + ".");
        }
        if (match.isFinished()) {
            throw new IllegalArgumentException(match.getStage() + " already has a result ("
                    + match.getResultDescription() + "). Playoff results cannot be overwritten; "
                    + "an administrator must reset the playoffs to redo them.");
        }
        if (teamManager.findById(match.getHomeTeam().getId()) == null
                || teamManager.findById(match.getAwayTeam().getId()) == null) {
            throw new IllegalArgumentException(
                    "A team in this playoff match is no longer registered.");
        }
        Team battingFirst = teamManager.findById(battingFirstTeamId);
        if (battingFirst == null || !match.involves(battingFirst)) {
            throw new IllegalArgumentException("Team ID " + battingFirstTeamId
                    + " is not one of the two teams in the " + match.getStage() + ".");
        }
        Team tieBreakWinner = null;
        if (tieBreakWinnerId > 0) {
            tieBreakWinner = teamManager.findById(tieBreakWinnerId);
            if (tieBreakWinner == null) {
                throw new IllegalArgumentException(
                        "Tie-break team ID " + tieBreakWinnerId + " is not a registered team.");
            }
        }

        // Throws IllegalArgumentException before anything is changed
        MatchResult result = ResultCalculator.calculate(
                match, battingFirst, first, second, tieBreakWinner, settings);
        match.complete(battingFirst, first, second, result);

        advance();
        return match;
    }

    /** Creates the next stage when its feeder matches are finished. */
    private void advance() {
        Match q1 = findByStage(MatchStage.QUALIFIER_1);
        Match elim = findByStage(MatchStage.ELIMINATOR);
        Match q2 = findByStage(MatchStage.QUALIFIER_2);
        Match fin = findByStage(MatchStage.FINAL);

        // 4-team format: Qualifier 2 = loser of Q1 v winner of Eliminator
        if (q1 != null && elim != null && q2 == null && q1.isFinished() && elim.isFinished()) {
            q2 = addMatch(loserOf(q1), elim.getWinner(), MatchStage.QUALIFIER_2, nextDate());
        }
        // 4-team format: Final = winner of Q1 v winner of Q2
        if (q1 != null && q2 != null && fin == null && q1.isFinished() && q2.isFinished()) {
            addMatch(q1.getWinner(), q2.getWinner(), MatchStage.FINAL, nextDate());
            return;
        }
        // 3-team format: Final = rank 1 v winner of Eliminator.
        // The league is locked once playoffs start, so rank 1 is unchanged.
        if (q1 == null && elim != null && fin == null && elim.isFinished()) {
            Team rankOne = pointsTable.getStandings().get(0);
            addMatch(rankOne, elim.getWinner(), MatchStage.FINAL, nextDate());
        }
    }

    private Team loserOf(Match m) {
        return m.getHomeTeam().equals(m.getWinner()) ? m.getAwayTeam() : m.getHomeTeam();
    }

    /** The day after the latest existing playoff match. */
    private LocalDate nextDate() {
        LocalDate latest = playoffMatches.get(0).getMatchDate();
        for (Match m : playoffMatches) {
            if (m.getMatchDate().isAfter(latest)) {
                latest = m.getMatchDate();
            }
        }
        return latest.plusDays(1);
    }

    // ------------------------------------------------------------------
    // Queries
    // ------------------------------------------------------------------

    public boolean hasStarted() {
        return !playoffMatches.isEmpty();
    }

    /** True when the Final has been completed. */
    public boolean isFinished() {
        Match fin = findByStage(MatchStage.FINAL);
        return fin != null && fin.isFinished();
    }

    /** The winner of the Final, or null if the Final has not been completed. */
    public Team getChampion() {
        return isFinished() ? findByStage(MatchStage.FINAL).getWinner() : null;
    }

    /** The loser of the Final, or null if the Final has not been completed. */
    public Team getRunnerUp() {
        return isFinished() ? loserOf(findByStage(MatchStage.FINAL)) : null;
    }

    /** The first playoff match still waiting for a score, or null. */
    public Match getNextPendingMatch() {
        for (Match m : playoffMatches) {
            if (m.isScheduled()) {
                return m;
            }
        }
        return null;
    }

    public Match findById(int playoffMatchId) {
        for (Match m : playoffMatches) {
            if (m.getMatchId() == playoffMatchId) {
                return m;
            }
        }
        return null;
    }

    /** @return the match of this stage, or null if it does not exist (yet) */
    public Match findByStage(MatchStage stage) {
        for (Match m : playoffMatches) {
            if (m.getStage() == stage) {
                return m;
            }
        }
        return null;
    }

    /** Read-only list of playoff matches in stage order. */
    public List<Match> getPlayoffMatches() {
        return Collections.unmodifiableList(playoffMatches);
    }

    // ------------------------------------------------------------------
    // Reset and loading
    // ------------------------------------------------------------------

    /**
     * Deletes ALL playoff matches so the playoffs can be started again.
     * League results are not touched. The caller must ask for confirmation.
     *
     * @return the number of playoff matches removed
     */
    public int resetPlayoffs() {
        int removed = playoffMatches.size();
        playoffMatches.clear();
        return removed;
    }

    /**
     * Adds a playoff match read from a data file (used by FileManager in Step 9).
     * Rejects non-playoff matches, duplicate IDs or stages, and unregistered teams.
     */
    public void addLoadedPlayoffMatch(Match match) {
        if (match == null) {
            throw new IllegalArgumentException("Playoff match record is missing.");
        }
        if (!match.getStage().isPlayoff()) {
            throw new IllegalArgumentException("A league match cannot be stored as a playoff match.");
        }
        if (teamManager.findById(match.getHomeTeam().getId()) == null
                || teamManager.findById(match.getAwayTeam().getId()) == null) {
            throw new IllegalArgumentException("Playoff match " + match.getMatchId()
                    + " refers to a team that is not registered.");
        }
        for (Match m : playoffMatches) {
            if (m.getMatchId() == match.getMatchId()) {
                throw new IllegalArgumentException(
                        "Playoff match ID " + match.getMatchId() + " already exists.");
            }
            if (m.getStage() == match.getStage()) {
                throw new IllegalArgumentException(
                        "The " + match.getStage() + " already exists.");
            }
        }
        playoffMatches.add(match);
        playoffMatches.sort(Comparator.comparingInt((Match m) -> m.getStage().ordinal()));
    }

    /**
     * Checks that loaded playoff matches form a possible progression
     * (e.g. no Final without the matches that feed it).
     * @return null if the structure is valid, otherwise a description of the problem
     */
    public String checkStructure() {
        Match q1 = findByStage(MatchStage.QUALIFIER_1);
        Match elim = findByStage(MatchStage.ELIMINATOR);
        Match q2 = findByStage(MatchStage.QUALIFIER_2);
        Match fin = findByStage(MatchStage.FINAL);

        if (q2 != null && (q1 == null || elim == null || !q1.isFinished() || !elim.isFinished())) {
            return "Qualifier 2 exists but Qualifier 1 and the Eliminator are not both completed.";
        }
        if (q1 != null && elim == null) {
            return "Qualifier 1 exists without an Eliminator.";
        }
        if (fin != null && q1 != null) {
            if (q2 == null || !q1.isFinished() || !q2.isFinished()) {
                return "The Final exists but Qualifier 1 and Qualifier 2 are not both completed.";
            }
        }
        if (fin != null && q1 == null && elim != null && !elim.isFinished()) {
            return "The Final exists but the Eliminator is not completed.";
        }
        return null;
    }
}
