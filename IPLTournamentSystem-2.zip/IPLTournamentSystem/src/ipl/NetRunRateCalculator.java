package ipl;

import java.util.Locale;

/**
 * Net run rate (NRR) calculation. No console input or output.
 *
 * NRR = (Runs Scored / Overs Faced) - (Runs Conceded / Overs Bowled)
 *
 * Cricket overs are NOT decimals, so every calculation works on LEGAL BALLS:
 * overs = balls / 6.0  (118 balls = 19.667 overs, not 19.4).
 *
 * Rule for overs counted (standard, no DLS):
 *  - An innings that is ALL OUT counts the FULL quota of overs
 *    (e.g. 20.0 overs), even if the team was dismissed earlier.
 *  - Any other innings counts the balls actually faced. This covers a
 *    successful chase that ends early, and a full-quota innings.
 *  - The same figure is used for the opponent's overs bowled.
 *  - No-result matches are never passed to this class, so they add nothing.
 */
public class NetRunRateCalculator {

    private NetRunRateCalculator() { }   // static helper: no objects needed

    /** Balls of this innings that count towards NRR (see the rule above). */
    public static int ballsCountedForNrr(Innings innings, TournamentSettings settings) {
        if (innings.isAllOut(settings.getMaxWickets())) {
            return settings.getMaxBalls();
        }
        return innings.getBalls();
    }

    /** Runs per over. Returns 0 when no balls were bowled (avoids division by zero). */
    public static double runRate(int runs, int balls) {
        if (balls <= 0) {
            return 0.0;
        }
        double overs = balls / (double) TournamentSettings.BALLS_PER_OVER;
        return runs / overs;
    }

    /** NRR from the four totals. Balls, not decimal overs, are used. */
    public static double calculate(int runsScored, int ballsFaced,
                                   int runsConceded, int ballsBowled) {
        return runRate(runsScored, ballsFaced) - runRate(runsConceded, ballsBowled);
    }

    /** NRR of a team from its current season totals. */
    public static double calculateFor(Team team) {
        return calculate(team.getRunsScored(), team.getBallsFaced(),
                team.getRunsConceded(), team.getBallsBowled());
    }

    /**
     * Rounds to three decimal places for display, e.g. "+0.512", "-0.199", "0.000".
     * Rounding is only for display; stored values keep full precision.
     */
    public static String format(double nrr) {
        double rounded = Math.round(nrr * 1000.0) / 1000.0;
        if (rounded == 0.0) {
            return "0.000";      // also removes the "-0.000" case
        }
        return String.format(Locale.US, "%+.3f", rounded);
    }
}
