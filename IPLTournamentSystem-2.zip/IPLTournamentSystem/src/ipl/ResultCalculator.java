package ipl;

/**
 * Validates entered scores and calculates the match result (Modules 4 and 5).
 * No console input or output; all methods are static.
 *
 * Rules used (standard limited-overs match, NO Duckworth-Lewis-Stern):
 *  1. Wickets cannot exceed the configured maximum; balls cannot exceed the quota.
 *  2. Both innings must contain at least one ball.
 *  3. The first innings must use the full quota of overs OR be all out.
 *  4. The second innings must use the full quota OR be all out, unless it
 *     has passed the target, when it may end early (a successful chase).
 *  5. A team that passed the target cannot be all out.
 *  6. More runs wins. Win by batting first: margin in runs.
 *     Win by chasing: margin in wickets remaining.
 *  7. Equal runs is a tie. A tie-break winner (e.g. Super Over) is REQUIRED
 *     in playoff matches and in league matches when the setting
 *     tieBreakInLeague is on. It is not allowed otherwise.
 */
public class ResultCalculator {

    private ResultCalculator() { }   // static helper: no objects needed

    /**
     * Checks the entered data.
     * @param tieBreakWinner winner of the tie-break, or null if there is none
     * @return null if everything is valid, otherwise a message describing the first problem
     */
    public static String validate(Match match, Team battingFirst, Innings first,
                                  Innings second, Team tieBreakWinner,
                                  TournamentSettings settings) {
        if (match == null) {
            return "Match not found.";
        }
        if (battingFirst == null || !match.involves(battingFirst)) {
            return "The team batting first must be one of the two teams in this match.";
        }
        if (first == null || second == null) {
            return "Both innings are required for a completed match.";
        }

        // Rule 1: limits from the settings
        String problem = first.validate(settings);
        if (problem != null) return "First innings: " + problem;
        problem = second.validate(settings);
        if (problem != null) return "Second innings: " + problem;

        // Rule 2: both innings must have started
        if (first.getBalls() < 1) {
            return "First innings: at least 1 ball must be faced. "
                    + "Use 'no result' if the match was abandoned.";
        }
        if (second.getBalls() < 1) {
            return "Second innings: at least 1 ball must be faced. "
                    + "Use 'no result' if the match was abandoned.";
        }

        int maxBalls = settings.getMaxBalls();
        int maxWickets = settings.getMaxWickets();

        // Rule 3: first innings must be complete
        if (!first.isAllOut(maxWickets) && first.getBalls() < maxBalls) {
            return "First innings: the team must face the full " + settings.getMaxOvers()
                    + " overs unless all out (rain-affected matches are not supported).";
        }

        // Rules 4 and 5: second innings
        boolean chaseWon = second.getRuns() > first.getRuns();
        if (chaseWon) {
            if (second.isAllOut(maxWickets)) {
                return "Second innings: a team that has passed the target cannot be all out.";
            }
        } else if (!second.isAllOut(maxWickets) && second.getBalls() < maxBalls) {
            return "Second innings: the target was not reached, so the team must face the full "
                    + settings.getMaxOvers() + " overs or be all out.";
        }

        // Rule 7: tie-break handling
        boolean tied = second.getRuns() == first.getRuns();
        boolean leagueTieBreak = settings.isTieBreakInLeague();
        boolean tieBreakRequired = tied
                && (match.getStage().isPlayoff() || leagueTieBreak);

        if (tieBreakWinner != null) {
            if (!tied) {
                return "A tie-break winner can be entered only when the scores are level.";
            }
            if (!tieBreakRequired) {
                return "League ties are recorded as ties. Tie-break winners are allowed "
                        + "only in playoff matches or when the league tie-break setting is on.";
            }
            if (!match.involves(tieBreakWinner)) {
                return "The tie-break winner must be one of the two teams in this match.";
            }
        } else if (tieBreakRequired) {
            return "The scores are level and this match needs a winner. "
                    + "Enter the tie-break (Super Over) winner.";
        }
        return null;
    }

    /**
     * Validates, then determines the result.
     * @throws IllegalArgumentException with the validation message if the data is invalid
     */
    public static MatchResult calculate(Match match, Team battingFirst, Innings first,
                                        Innings second, Team tieBreakWinner,
                                        TournamentSettings settings) {
        String problem = validate(match, battingFirst, first, second, tieBreakWinner, settings);
        if (problem != null) {
            throw new IllegalArgumentException(problem);
        }

        Team chasing = battingFirst.equals(match.getHomeTeam())
                ? match.getAwayTeam() : match.getHomeTeam();

        if (second.getRuns() > first.getRuns()) {
            // Chasing team wins; margin = wickets in hand
            int wicketsLeft = settings.getMaxWickets() - second.getWickets();
            return MatchResult.win(chasing, wicketsLeft, MatchResult.MarginType.WICKETS,
                    chasing.getName() + " won by " + wicketsLeft + " "
                            + plural(wicketsLeft, "wicket"));
        }
        if (first.getRuns() > second.getRuns()) {
            // Team batting first wins; margin = run difference
            int runMargin = first.getRuns() - second.getRuns();
            return MatchResult.win(battingFirst, runMargin, MatchResult.MarginType.RUNS,
                    battingFirst.getName() + " won by " + runMargin + " "
                            + plural(runMargin, "run"));
        }
        // Scores level
        if (tieBreakWinner != null) {
            return MatchResult.win(tieBreakWinner, 0, MatchResult.MarginType.TIE_BREAK,
                    tieBreakWinner.getName() + " won the tie-break (scores level at "
                            + first.getRuns() + ")");
        }
        return MatchResult.tie("Match tied (scores level at " + first.getRuns() + ")");
    }

    /** The result stored for an abandoned match. No winner is declared. */
    public static MatchResult noResult() {
        return MatchResult.noResult("No result - match abandoned");
    }

    private static String plural(int count, String word) {
        return count == 1 ? word : word + "s";
    }
}
