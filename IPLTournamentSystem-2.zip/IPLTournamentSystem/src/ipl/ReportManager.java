package ipl;

import java.util.ArrayList;
import java.util.List;

/**
 * Builds the formatted console reports.
 * Team table (Step 3), match table (Step 4), match result summary (Step 5),
 * points table and NRR details (Step 6), team statistics and tournament
 * reports (Step 7).
 *
 * Every method only PRINTS the data it is given. The caller (TournamentManager)
 * decides what to pass, so a report can never invent a champion or a standing.
 */
public class ReportManager {

    /** Returns a line of '-' characters of the given length. */
    public static String line(int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append('-');
        }
        return sb.toString();
    }

    /** Prints teams as a table, or a message when the list is empty. */
    public static void printTeamList(List<Team> teams) {
        if (teams == null || teams.isEmpty()) {
            System.out.println("No teams to display.");
            return;
        }
        System.out.println(String.format("%-4s %-28s %-6s %-14s",
                "ID", "Team Name", "Short", "Home City"));
        System.out.println(line(55));
        for (Team t : teams) {
            System.out.println(t.toRow());
        }
        System.out.println(line(55));
        System.out.println("Total teams: " + teams.size());
    }

    /** Prints matches as a table, or a message when the list is empty. */
    public static void printMatchList(List<Match> matches) {
        if (matches == null || matches.isEmpty()) {
            System.out.println("No matches to display.");
            return;
        }
        System.out.println(String.format("%-4s %-4s %-10s %-14s %-24s %-10s",
                "No.", "ID", "Date", "Fixture", "Venue", "Status"));
        System.out.println(line(71));
        for (Match m : matches) {
            System.out.println(m.toRow());
        }
        System.out.println(line(71));
        System.out.println("Total matches: " + matches.size());
    }

    /** Prints the result summary of one match (Module 5 format). */
    public static void printMatchResult(Match match) {
        if (match == null) {
            System.out.println("Match not found.");
            return;
        }
        System.out.println("Match: " + match.getHomeTeam().getName()
                + " vs " + match.getAwayTeam().getName()
                + "  [" + match.getStage() + " no. " + match.getMatchNumber() + "]");
        if (match.getStatus() == MatchStatus.SCHEDULED) {
            System.out.println("Status: SCHEDULED for " + match.getMatchDate()
                    + " at " + match.getVenue());
            System.out.println("Result: Not played yet.");
            return;
        }
        if (match.getStatus() == MatchStatus.NO_RESULT) {
            System.out.println("Result: " + match.getResultDescription());
            return;
        }
        Team home = match.getHomeTeam();
        Team away = match.getAwayTeam();
        System.out.println(home.getName() + " Score: " + match.getInningsFor(home)
                + (home.equals(match.getBattingFirst()) ? "  (batted first)" : ""));
        System.out.println(away.getName() + " Score: " + match.getInningsFor(away)
                + (away.equals(match.getBattingFirst()) ? "  (batted first)" : ""));
        System.out.println("Result: " + match.getResultDescription());
    }

    /**
     * Prints the points table. The list must already be sorted (rank 1 first),
     * normally the result of PointsTable.getStandings().
     */
    public static void printPointsTable(List<Team> ranked, int matchesCounted) {
        if (ranked == null || ranked.isEmpty()) {
            System.out.println("No teams registered.");
            return;
        }
        if (matchesCounted == 0) {
            System.out.println("No matches have been completed yet; all teams are on zero.");
        }
        System.out.println(String.format("%-4s %-28s %3s %3s %3s %3s %3s %4s %8s",
                "Rank", "Team", "MP", "W", "L", "T", "NR", "Pts", "NRR"));
        System.out.println(line(67));
        int rank = 1;
        for (Team t : ranked) {
            System.out.println(String.format("%-4d %-28s %3d %3d %3d %3d %3d %4d %8s",
                    rank, t.getName(), t.getMatchesPlayed(), t.getMatchesWon(),
                    t.getMatchesLost(), t.getMatchesTied(), t.getMatchesNoResult(),
                    t.getTotalPoints(), NetRunRateCalculator.format(t.getNetRunRate())));
            rank++;
        }
        System.out.println(line(67));
        System.out.println("MP = matches played (includes no result), NR = no result, "
                + "Pts = points, NRR = net run rate");
    }

    /** Prints the figures behind each team's net run rate. */
    public static void printNetRunRateDetails(List<Team> teams) {
        if (teams == null || teams.isEmpty()) {
            System.out.println("No teams registered.");
            return;
        }
        System.out.println(String.format("%-6s %9s %11s %12s %13s %9s",
                "Team", "Runs For", "Overs Faced", "Runs Against", "Overs Bowled", "NRR"));
        System.out.println(line(65));
        for (Team t : teams) {
            System.out.println(String.format("%-6s %9d %11s %12d %13s %9s",
                    t.getShortName(), t.getRunsScored(), t.getOversFacedText(),
                    t.getRunsConceded(), t.getOversBowledText(),
                    NetRunRateCalculator.format(t.getNetRunRate())));
        }
        System.out.println(line(65));
        System.out.println("An all-out innings counts the full quota of overs. "
                + "Overs are shown in cricket notation (balls / 6).");
    }

    // ------------------------------------------------------------------
    // Team statistics (Module 10)
    // ------------------------------------------------------------------

    /** Prints the full statistics of one team. */
    public static void printTeamStatistics(TeamStatistics s) {
        Team t = s.getTeam();
        System.out.println("=== Team Statistics: " + t.getName() + " (" + t.getShortName() + ") ===");
        System.out.println("Home city              : " + t.getHomeCity());
        String position = (s.getPosition() == 0)
                ? "not ranked"
                : s.getPosition() + " of " + s.getTotalTeams();
        if (s.getPosition() != 0 && !s.isTableBasedOnResults()) {
            position += " (no matches completed yet; order is by team ID)";
        }
        System.out.println("Current position       : " + position);
        System.out.println("Matches played         : " + t.getMatchesPlayed());
        System.out.println("Won                    : " + t.getMatchesWon());
        System.out.println("Lost                   : " + t.getMatchesLost());
        System.out.println("Tied                   : " + t.getMatchesTied());
        System.out.println("No result              : " + t.getMatchesNoResult());
        System.out.println(String.format("Win percentage         : %.1f%%", t.getWinPercentage())
                + "   (wins / (matches played - no results) x 100)");
        System.out.println("Total points           : " + t.getTotalPoints());
        System.out.println("Runs scored            : " + t.getRunsScored()
                + " (" + t.getOversFacedText() + " overs faced)");
        System.out.println("Runs conceded          : " + t.getRunsConceded()
                + " (" + t.getOversBowledText() + " overs bowled)");
        System.out.println("Net run rate           : " + NetRunRateCalculator.format(t.getNetRunRate()));
        System.out.println("Longest winning streak : " + s.getLongestWinStreak());
        System.out.println("Biggest win by runs    : " + describeBiggestWin(s.getBiggestWinByRuns(), t, "run"));
        System.out.println("Biggest win by wickets : " + describeBiggestWin(s.getBiggestWinByWickets(), t, "wicket"));

        System.out.println();
        System.out.println("Completed matches (" + s.getCompletedMatches().size() + "):");
        if (s.getCompletedMatches().isEmpty()) {
            System.out.println("  None yet.");
        }
        for (Match m : s.getCompletedMatches()) {
            System.out.println(matchLineFor(m, t, m.getResultDescription()));
        }
        System.out.println();
        System.out.println("Upcoming matches (" + s.getUpcomingMatches().size() + "):");
        if (s.getUpcomingMatches().isEmpty()) {
            System.out.println("  None.");
        }
        for (Match m : s.getUpcomingMatches()) {
            System.out.println(matchLineFor(m, t, "at " + m.getVenue()));
        }
    }

    private static String describeBiggestWin(Match m, Team team, String unit) {
        if (m == null) {
            return "none";
        }
        int margin = m.getResult().getMargin();
        Team opponent = m.getHomeTeam().equals(team) ? m.getAwayTeam() : m.getHomeTeam();
        return margin + " " + (margin == 1 ? unit : unit + "s")
                + " (match " + m.getMatchNumber() + " vs " + opponent.getShortName() + ")";
    }

    /** One line about a match, seen from the point of view of 'team'. */
    private static String matchLineFor(Match m, Team team, String detail) {
        boolean home = m.getHomeTeam().equals(team);
        Team opponent = home ? m.getAwayTeam() : m.getHomeTeam();
        return String.format("  Match %-3d %s  vs %-4s (%s)  %s",
                m.getMatchNumber(), m.getMatchDate(), opponent.getShortName(),
                home ? "home" : "away", detail);
    }

    // ------------------------------------------------------------------
    // Tournament reports (Module 12)
    // ------------------------------------------------------------------

    /** Report 3: results of all finished league matches. */
    public static void printCompletedResults(List<Match> finished) {
        if (finished == null || finished.isEmpty()) {
            System.out.println("No matches have been completed yet.");
            return;
        }
        for (Match m : finished) {
            printMatchResult(m);
            System.out.println();
        }
        System.out.println("Matches shown: " + finished.size());
    }

    /**
     * Report 5: the league-stage leader. This is NOT the champion.
     *
     * @param standings        teams sorted by the ranking rules
     * @param matchesCounted   finished league matches
     * @param matchesRemaining league matches still scheduled
     */
    public static void printLeagueLeader(List<Team> standings, int matchesCounted,
                                         int matchesRemaining) {
        if (standings == null || standings.isEmpty() || matchesCounted == 0) {
            System.out.println("No league matches have been completed, so there is no league leader yet.");
            return;
        }
        Team leader = standings.get(0);
        System.out.println("League-stage leader: " + leader.getName() + " ("
                + leader.getTotalPoints() + " points, NRR "
                + NetRunRateCalculator.format(leader.getNetRunRate()) + ")");
        if (standings.size() > 1 && levelOnAllCriteria(leader, standings.get(1))) {
            System.out.println("Note: " + standings.get(1).getName() + " is level with the leader on "
                    + "points, NRR and wins; the order is decided by team ID only.");
        }
        if (matchesRemaining > 0) {
            System.out.println("Provisional: " + matchesRemaining
                    + " league match(es) are still to be played.");
        }
        System.out.println("The league leader is NOT the tournament champion; "
                + "the champion is decided by the playoff Final.");
    }

    private static boolean levelOnAllCriteria(Team a, Team b) {
        return a.getTotalPoints() == b.getTotalPoints()
                && a.getMatchesWon() == b.getMatchesWon()
                && Math.round(a.getNetRunRate() * 1000.0) == Math.round(b.getNetRunRate() * 1000.0);
    }

    /**
     * Reports 6 and 7: qualified and eliminated teams.
     * Both lists must be in rank order (qualified first).
     */
    public static void printQualification(List<Team> qualified, List<Team> eliminated,
                                          int matchesRemaining) {
        if (qualified == null || qualified.isEmpty()) {
            System.out.println("No teams have qualified: there are no registered teams "
                    + "or no matches have been played.");
            return;
        }
        if (matchesRemaining > 0) {
            System.out.println("PROVISIONAL: " + matchesRemaining
                    + " league match(es) are still to be played.");
        }
        System.out.println("Qualified for the playoffs:");
        System.out.println(String.format("  %-4s %-28s %4s %8s", "Rank", "Team", "Pts", "NRR"));
        int rank = 1;
        for (Team t : qualified) {
            System.out.println(String.format("  %-4d %-28s %4d %8s", rank, t.getName(),
                    t.getTotalPoints(), NetRunRateCalculator.format(t.getNetRunRate())));
            rank++;
        }
        System.out.println();
        if (eliminated == null || eliminated.isEmpty()) {
            System.out.println("Eliminated: none (every team qualified).");
            return;
        }
        System.out.println("Not qualified:");
        for (Team t : eliminated) {
            System.out.println(String.format("  %-4d %-28s %4d %8s", rank, t.getName(),
                    t.getTotalPoints(), NetRunRateCalculator.format(t.getNetRunRate())));
            rank++;
        }
    }

    /** Report 8: win percentage of every team. */
    public static void printWinPercentages(List<Team> teams) {
        if (teams == null || teams.isEmpty()) {
            System.out.println("No teams registered.");
            return;
        }
        System.out.println(String.format("%-28s %3s %3s %3s %7s",
                "Team", "MP", "NR", "W", "Win %"));
        System.out.println(line(48));
        for (Team t : teams) {
            System.out.println(String.format("%-28s %3d %3d %3d %6.1f%%",
                    t.getName(), t.getMatchesPlayed(), t.getMatchesNoResult(),
                    t.getMatchesWon(), t.getWinPercentage()));
        }
        System.out.println(line(48));
        System.out.println("Win % = wins / (matches played - no results) x 100");
    }

    /** Report 9: team(s) with the most runs scored in the league stage. */
    public static void printHighestScoring(List<Team> teams) {
        int best = 0;
        if (teams != null) {
            for (Team t : teams) {
                best = Math.max(best, t.getRunsScored());
            }
        }
        if (best == 0) {
            System.out.println("No runs have been recorded yet.");
            return;
        }
        for (Team t : teams) {
            if (t.getRunsScored() == best) {
                System.out.println("Highest-scoring team (total runs): " + t.getName() + " - "
                        + best + " runs in " + t.getOversFacedText() + " overs faced");
            }
        }
    }

    /** Report 10: team(s) with the best net run rate. */
    public static void printBestNrr(List<Team> teams, boolean hasData) {
        if (!hasData || teams == null || teams.isEmpty()) {
            System.out.println("No net run rate is available because no matches have been completed.");
            return;
        }
        long best = Long.MIN_VALUE;
        for (Team t : teams) {
            best = Math.max(best, Math.round(t.getNetRunRate() * 1000.0));
        }
        for (Team t : teams) {
            if (Math.round(t.getNetRunRate() * 1000.0) == best) {
                System.out.println("Best net run rate: " + t.getName() + " ("
                        + NetRunRateCalculator.format(t.getNetRunRate()) + ")");
            }
        }
    }

    /** Report 11: playoff matches and their results. */
    public static void printPlayoffResults(List<Match> playoffMatches) {
        if (playoffMatches == null || playoffMatches.isEmpty()) {
            System.out.println("The playoffs have not been played yet.");
            return;
        }
        System.out.println(String.format("%-12s %-12s %s", "Stage", "Fixture", "Result"));
        System.out.println(line(60));
        for (Match m : playoffMatches) {
            System.out.println(String.format("%-12s %-12s %s", m.getStage().getLabel(),
                    m.getHomeTeam().getShortName() + " vs " + m.getAwayTeam().getShortName(),
                    m.getResultDescription()));
        }
    }

    /**
     * Report 12: the tournament champion. Pass null when the Final has not
     * been completed; no champion is announced in that case.
     */
    public static void printChampion(Team champion) {
        if (champion == null) {
            System.out.println("The tournament champion has not been decided yet "
                    + "(the Final has not been completed).");
            return;
        }
        System.out.println("*** TOURNAMENT CHAMPION: " + champion.getName()
                + " (" + champion.getShortName() + ") ***");
    }
}
