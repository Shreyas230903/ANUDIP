package ipl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The tournament points table.
 *
 * SINGLE SOURCE OF TRUTH: the league match records in MatchManager.
 * Team statistics are never edited directly. recalculate() sets every
 * team's statistics to zero and rebuilds them by going through the finished
 * league matches once each. Because of this:
 *  - a match can never be counted twice,
 *  - an unplayed (SCHEDULED) match gives no points,
 *  - a corrected match is reflected automatically,
 *  - playoff matches never affect the table (they are not in MatchManager).
 *
 * A NO_RESULT match counts as a match played (with the no-result points)
 * but adds no runs or overs, so it has no effect on NRR.
 */
public class PointsTable {

    private final TeamManager teamManager;
    private final MatchManager matchManager;
    private final TournamentSettings settings;
    private Comparator<Team> comparator = StandingsComparators.defaultOrder();
    private int matchesCounted = 0;

    public PointsTable(TeamManager teamManager, MatchManager matchManager,
                       TournamentSettings settings) {
        this.teamManager = teamManager;
        this.matchManager = matchManager;
        this.settings = settings;
    }

    /** Changes the ranking rules (see StandingsComparators.chain). */
    public void setComparator(Comparator<Team> comparator) {
        if (comparator == null) {
            throw new IllegalArgumentException("A ranking comparator is required.");
        }
        this.comparator = comparator;
    }

    // ------------------------------------------------------------------
    // Recalculation
    // ------------------------------------------------------------------

    /** Rebuilds every team's statistics and NRR from the match records. */
    public void recalculate() {
        teamManager.resetSeasonStatistics();
        matchesCounted = 0;

        Set<Integer> countedIds = new HashSet<>();   // safety: never count a match twice
        for (Match m : matchManager.getAllMatches()) {
            if (!m.isFinished() || m.getStage() != MatchStage.LEAGUE) {
                continue;
            }
            if (!countedIds.add(m.getMatchId())) {
                continue;
            }
            applyMatch(m);
            matchesCounted++;
        }

        for (Team t : teamManager.getAllTeams()) {
            t.setNetRunRate(NetRunRateCalculator.calculateFor(t));
        }
    }

    /** Adds one finished match to the two teams' statistics. */
    private void applyMatch(Match m) {
        Team home = teamManager.findById(m.getHomeTeam().getId());
        Team away = teamManager.findById(m.getAwayTeam().getId());
        if (home == null || away == null) {
            return;   // cannot happen for matches accepted by MatchManager
        }

        if (m.getStatus() == MatchStatus.NO_RESULT) {
            home.recordNoResult(settings.getPointsForNoResult());
            away.recordNoResult(settings.getPointsForNoResult());
            return;                                  // no runs or overs counted
        }

        Team winner = m.getWinner();
        if (winner == null) {                        // tie
            home.recordTie(settings.getPointsForTie());
            away.recordTie(settings.getPointsForTie());
        } else if (winner.equals(home)) {
            home.recordWin(settings.getPointsForWin());
            away.recordLoss(settings.getPointsForLoss());
        } else {
            away.recordWin(settings.getPointsForWin());
            home.recordLoss(settings.getPointsForLoss());
        }

        addInningsData(m, home, away);
        addInningsData(m, away, home);
    }

    /** Runs scored/conceded and overs faced/bowled of one team in one match. */
    private void addInningsData(Match m, Team team, Team opponent) {
        Innings own = m.getInningsFor(team);
        Innings against = m.getInningsFor(opponent);
        team.addInningsData(
                own.getRuns(), NetRunRateCalculator.ballsCountedForNrr(own, settings),
                against.getRuns(), NetRunRateCalculator.ballsCountedForNrr(against, settings));
    }

    // ------------------------------------------------------------------
    // Standings
    // ------------------------------------------------------------------

    /**
     * Recalculates, then returns all teams sorted by the ranking rules.
     * The returned list is a copy; position 0 is rank 1.
     */
    public List<Team> getStandings() {
        recalculate();
        List<Team> sorted = new ArrayList<>(teamManager.getAllTeams());
        sorted.sort(comparator);
        return sorted;
    }

    /** The first n teams of the standings (all teams if n is larger). */
    public List<Team> getTopTeams(int n) {
        if (n < 1) {
            throw new IllegalArgumentException("Number of teams must be at least 1.");
        }
        List<Team> standings = getStandings();
        return new ArrayList<>(standings.subList(0, Math.min(n, standings.size())));
    }

    /** Rank (1 = best) of a team, or 0 if the team is not registered. */
    public int getRank(Team team) {
        List<Team> standings = getStandings();
        for (int i = 0; i < standings.size(); i++) {
            if (standings.get(i).equals(team)) {
                return i + 1;
            }
        }
        return 0;
    }

    /** Number of finished league matches counted by the last recalculation. */
    public int getMatchesCounted() {
        return matchesCounted;
    }

    /** True if at least one league match has been counted. */
    public boolean hasData() {
        return matchesCounted > 0;
    }
}
