package ipl;

/**
 * Records one innings of a match.
 * Overs are stored as LEGAL BALLS because cricket overs are not decimals:
 * 19.4 overs means 19 overs + 4 balls = 118 balls, NOT 19.4 as a decimal.
 */
public class Innings {

    private final int runs;
    private final int wickets;
    private final int balls;    // total legal balls faced

    /**
     * @param runs    runs scored (>= 0)
     * @param wickets wickets lost (>= 0)
     * @param balls   total legal balls faced (>= 0)
     */
    public Innings(int runs, int wickets, int balls) {
        if (runs < 0) {
            throw new IllegalArgumentException("Runs cannot be negative.");
        }
        if (wickets < 0) {
            throw new IllegalArgumentException("Wickets cannot be negative.");
        }
        if (balls < 0) {
            throw new IllegalArgumentException("Balls cannot be negative.");
        }
        this.runs = runs;
        this.wickets = wickets;
        this.balls = balls;
    }

    // ---- Overs and balls conversion ----

    /**
     * Converts overs and extra balls into total legal balls.
     * Example: toBalls(19, 4) returns 118.
     */
    public static int toBalls(int overs, int extraBalls) {
        if (overs < 0) {
            throw new IllegalArgumentException("Overs cannot be negative.");
        }
        if (extraBalls < 0 || extraBalls >= TournamentSettings.BALLS_PER_OVER) {
            throw new IllegalArgumentException("Balls must be between 0 and "
                    + (TournamentSettings.BALLS_PER_OVER - 1) + ".");
        }
        return overs * TournamentSettings.BALLS_PER_OVER + extraBalls;
    }

    /**
     * Converts total balls to cricket notation.
     * Example: formatOvers(118) returns "19.4"; formatOvers(120) returns "20.0".
     */
    public static String formatOvers(int totalBalls) {
        return (totalBalls / TournamentSettings.BALLS_PER_OVER) + "."
                + (totalBalls % TournamentSettings.BALLS_PER_OVER);
    }

    // ---- Queries ----

    public int getRuns()    { return runs; }
    public int getWickets() { return wickets; }
    public int getBalls()   { return balls; }

    public String getOversText() {
        return formatOvers(balls);
    }

    /** A team is all out when it has lost the maximum number of wickets. */
    public boolean isAllOut(int maxWickets) {
        return wickets >= maxWickets;
    }

    /** Returns the score in cricket style, e.g. "175/7". */
    public String getScoreText() {
        return runs + "/" + wickets;
    }

    /**
     * Basic validation against the tournament rules.
     * @return null if valid, otherwise an error message.
     * Match-level rules (e.g. a chase ending early) are checked by ResultCalculator.
     */
    public String validate(TournamentSettings settings) {
        if (wickets > settings.getMaxWickets()) {
            return "Wickets cannot exceed " + settings.getMaxWickets() + ".";
        }
        if (balls > settings.getMaxBalls()) {
            return "Balls faced cannot exceed the quota of "
                    + settings.getMaxOvers() + " overs.";
        }
        return null;
    }

    @Override
    public String toString() {
        return getScoreText() + " (" + getOversText() + " ov)";
    }
}
