package ipl;

/**
 * Entry point of the IPL-style Tournament Management System.
 * Runs the 17-option menu until the user chooses Exit.
 * It contains no business logic: every option is handled by ConsoleMenu.
 *
 * Usage:  java -cp bin ipl.Main [data-folder]      (default folder: data)
 */
public class Main {

    public static void main(String[] args) {
        String dataFolder = (args.length > 0) ? args[0] : "data";
        TournamentManager tournament = new TournamentManager(dataFolder);
        ConsoleMenu menu = new ConsoleMenu(tournament);

        try {
            menu.showWelcomeAndLoad();

            boolean running = true;
            while (running) {
                menu.printMainMenu();
                // readInt repeats until the number is 1-17, so an invalid choice cannot crash
                int choice = InputHelper.readInt("Enter your choice (1-17): ", 1, 17);
                switch (choice) {
                    case 1:  menu.registerTeam();          break;
                    case 2:  menu.viewAllTeams();          break;
                    case 3:  menu.searchTeam();            break;
                    case 4:  menu.createSchedule();        break;
                    case 5:  menu.viewSchedule();          break;
                    case 6:  menu.enterMatchScore();       break;
                    case 7:  menu.viewMatchResult();       break;
                    case 8:  menu.updatePointsTable();     break;
                    case 9:  menu.displayPointsTable();    break;
                    case 10: menu.calculateNetRunRate();   break;
                    case 11: menu.displayTopTeams();       break;
                    case 12: menu.displayQualifiedTeams(); break;
                    case 13: menu.simulatePlayoffs();      break;
                    case 14: menu.displayChampion();       break;
                    case 15: menu.viewTeamStatistics();    break;
                    case 16: menu.saveData();              break;
                    case 17: running = !menu.exitApplication(); break;
                    default: break;   // unreachable: readInt limits the range
                }
            }
        } catch (IllegalStateException e) {
            // Thrown by InputHelper when the input stream ends (e.g. Ctrl+D)
            System.out.println("\nInput ended unexpectedly (" + e.getMessage() + "). Saving and stopping.");
            menu.saveBeforeStopping();
        }
    }
}
