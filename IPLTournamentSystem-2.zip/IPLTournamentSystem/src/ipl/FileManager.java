package ipl;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Saves and loads the tournament with plain text files (Module 11).
 * No console input or output: problems are returned in a LoadResult
 * or thrown as IOException, and the caller shows them.
 *
 * FILES (UTF-8, one record per line, '|' separates fields,
 * blank lines and lines starting with '#' are ignored):
 *
 *  teams.txt
 *    id|name|shortName|homeCity
 *
 *  matches.txt (league matches)
 *    matchId|matchNo|homeId|awayId|date|venue|status|battingFirstId|
 *    inn1Runs|inn1Wkts|inn1Balls|inn2Runs|inn2Wkts|inn2Balls|tieBreakWinnerId
 *
 *  playoff_matches.txt
 *    stage|  followed by the same fields as matches.txt
 *
 *  tournament_settings.txt
 *    key=value, one setting per line
 *
 *  - date is yyyy-MM-dd; status is SCHEDULED, COMPLETED or NO_RESULT.
 *  - innings values are in runs, wickets and LEGAL BALLS (overs x 6 + balls).
 *  - battingFirstId, innings fields and tieBreakWinnerId are 0 when not used.
 *
 * ONLY SOURCE DATA IS SAVED. The winner, the result text, team statistics,
 * the points table and NRR are NOT stored. On loading, each result is
 * recalculated from the saved scores with the same rules used for entry, and
 * the points table is rebuilt from the match records.
 */
public class FileManager {

    public static final String TEAMS_FILE = "teams.txt";
    public static final String MATCHES_FILE = "matches.txt";
    public static final String PLAYOFF_FILE = "playoff_matches.txt";
    public static final String SETTINGS_FILE = "tournament_settings.txt";

    private static final int TEAM_FIELDS = 4;
    private static final int LEAGUE_FIELDS = 15;
    private static final int PLAYOFF_FIELDS = 16;   // one extra field: the stage

    private final Path dataDir;
    private final TeamManager teamManager;
    private final MatchManager matchManager;
    private final PlayoffManager playoffManager;
    private final PointsTable pointsTable;
    private final TournamentSettings settings;

    /** One line-loading action. Throws IllegalArgumentException for a bad record. */
    private interface RecordLoader {
        void load(String line);
    }

    /** What happened during loading. */
    public static class LoadResult {
        private final List<String> missingFiles = new ArrayList<>();
        private final List<String> warnings = new ArrayList<>();
        private int settingsLoaded;
        private int teamsLoaded;
        private int matchesLoaded;
        private int playoffMatchesLoaded;
        private int matchesCounted;      // finished league matches in the rebuilt points table

        public List<String> getMissingFiles()  { return missingFiles; }
        public List<String> getWarnings()      { return warnings; }
        public int getSettingsLoaded()         { return settingsLoaded; }
        public int getTeamsLoaded()            { return teamsLoaded; }
        public int getMatchesLoaded()          { return matchesLoaded; }
        public int getPlayoffMatchesLoaded()   { return playoffMatchesLoaded; }
        public int getMatchesCounted()         { return matchesCounted; }

        /** True when none of the four data files exists (first run). */
        public boolean isFreshStart() { return missingFiles.size() == 4; }

        public boolean hasWarnings()  { return !warnings.isEmpty(); }

        /** A short text summary for the console. */
        public String summary() {
            if (isFreshStart()) {
                return "No saved data found. Starting a new, empty tournament.";
            }
            return "Loaded " + teamsLoaded + " team(s), " + matchesLoaded + " league match(es), "
                    + playoffMatchesLoaded + " playoff match(es) and " + settingsLoaded
                    + " setting(s); " + matchesCounted + " finished league match(es) counted "
                    + "in the points table.";
        }
    }

    public FileManager(String dataDirectory, TeamManager teamManager, MatchManager matchManager,
                       PlayoffManager playoffManager, PointsTable pointsTable,
                       TournamentSettings settings) {
        this.dataDir = Paths.get(dataDirectory);
        this.teamManager = teamManager;
        this.matchManager = matchManager;
        this.playoffManager = playoffManager;
        this.pointsTable = pointsTable;
        this.settings = settings;
    }

    // ==================================================================
    // LOADING
    // ==================================================================

    /**
     * Loads settings, teams, league matches and playoff matches, in that order,
     * then rebuilds the points table. Missing files are not an error. A bad record
     * is skipped and reported in the result; the rest of the file is still loaded.
     *
     * @throws IllegalStateException if tournament data is already in memory,
     *                               which would create duplicate records
     */
    public LoadResult loadAll() {
        if (!teamManager.isEmpty() || matchManager.getMatchCount() > 0
                || playoffManager.hasStarted()) {
            throw new IllegalStateException(
                    "Data is already loaded; loading again would create duplicate records.");
        }
        LoadResult result = new LoadResult();

        // Settings first: the rules decide whether saved scores are valid
        result.settingsLoaded = loadFile(SETTINGS_FILE, result, this::loadSettingLine);
        result.teamsLoaded = loadFile(TEAMS_FILE, result, this::loadTeamLine);
        result.matchesLoaded = loadFile(MATCHES_FILE, result, this::loadLeagueMatchLine);
        result.playoffMatchesLoaded = loadFile(PLAYOFF_FILE, result, this::loadPlayoffMatchLine);

        // Playoff records must form a possible progression; otherwise discard them
        String structureProblem = playoffManager.checkStructure();
        if (structureProblem != null) {
            int removed = playoffManager.resetPlayoffs();
            result.playoffMatchesLoaded = 0;
            result.warnings.add(PLAYOFF_FILE + ": " + structureProblem + " All " + removed
                    + " playoff record(s) were discarded.");
            backupBadFile(PLAYOFF_FILE, result);
        }

        // Rebuild all statistics and NRR from the match records
        pointsTable.recalculate();
        result.matchesCounted = pointsTable.getMatchesCounted();
        return result;
    }

    /** Reads one file and passes each record line to the loader. Returns the number loaded. */
    private int loadFile(String fileName, LoadResult result, RecordLoader loader) {
        Path path = dataDir.resolve(fileName);
        if (!Files.exists(path)) {
            result.missingFiles.add(fileName);
            return 0;
        }
        List<String> lines;
        try {
            lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            result.warnings.add(fileName + ": the file could not be read (" + e.getMessage()
                    + "). Nothing was loaded from it.");
            backupBadFile(fileName, result);   // the next save would otherwise overwrite it
            return 0;
        }

        int warningsBefore = result.warnings.size();
        int loaded = 0;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }
            try {
                loader.load(line);
                loaded++;
            } catch (IllegalArgumentException e) {
                result.warnings.add(fileName + " line " + (i + 1) + ": "
                        + e.getMessage() + " (record skipped)");
            }
        }
        if (result.warnings.size() > warningsBefore) {
            backupBadFile(fileName, result);
        }
        return loaded;
    }

    /**
     * Keeps a copy of a file that had bad records as "<name>.bad", because the next
     * save writes only the valid records and would otherwise erase the originals.
     */
    private void backupBadFile(String fileName, LoadResult result) {
        Path source = dataDir.resolve(fileName);
        Path backup = dataDir.resolve(fileName + ".bad");
        try {
            if (Files.exists(source)) {
                Files.copy(source, backup, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            result.warnings.add(fileName + ": could not keep a backup copy of the bad file ("
                    + e.getMessage() + ").");
        }
    }

    // ---- Record loaders ----

    private void loadSettingLine(String line) {
        int eq = line.indexOf('=');
        if (eq <= 0) {
            throw new IllegalArgumentException("expected 'key=value'");
        }
        String key = line.substring(0, eq).trim();
        String value = line.substring(eq + 1).trim();
        switch (key) {
            case "pointsForWin":      settings.setPointsForWin(parseInt(value, key)); break;
            case "pointsForLoss":     settings.setPointsForLoss(parseInt(value, key)); break;
            case "pointsForTie":      settings.setPointsForTie(parseInt(value, key)); break;
            case "pointsForNoResult": settings.setPointsForNoResult(parseInt(value, key)); break;
            case "maxOvers":          settings.setMaxOvers(parseInt(value, key)); break;
            case "maxWickets":        settings.setMaxWickets(parseInt(value, key)); break;
            case "qualifiersCount":   settings.setQualifiersCount(parseInt(value, key)); break;
            case "doubleRoundRobin":  settings.setDoubleRoundRobin(parseBoolean(value, key)); break;
            case "playoffsEnabled":   settings.setPlayoffsEnabled(parseBoolean(value, key)); break;
            case "tieBreakInLeague":  settings.setTieBreakInLeague(parseBoolean(value, key)); break;
            default:
                throw new IllegalArgumentException("unknown setting '" + key + "'");
        }
    }

    private void loadTeamLine(String line) {
        String[] f = splitFields(line, TEAM_FIELDS);
        int id = parseInt(f[0], "team ID");
        // Team and TeamManager reject empty, invalid and duplicate values
        teamManager.addLoadedTeam(new Team(id, f[1], f[2], f[3]));
    }

    private void loadLeagueMatchLine(String line) {
        String[] f = splitFields(line, LEAGUE_FIELDS);
        matchManager.addLoadedMatch(buildMatch(f, 0, MatchStage.LEAGUE));
    }

    private void loadPlayoffMatchLine(String line) {
        String[] f = splitFields(line, PLAYOFF_FIELDS);
        MatchStage stage;
        try {
            stage = MatchStage.valueOf(f[0]);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("unknown stage '" + f[0] + "'");
        }
        if (!stage.isPlayoff()) {
            throw new IllegalArgumentException("stage '" + f[0] + "' is not a playoff stage");
        }
        Match match = buildMatch(f, 1, stage);
        if (match.getStatus() == MatchStatus.NO_RESULT) {
            throw new IllegalArgumentException("a playoff match cannot have 'no result'");
        }
        playoffManager.addLoadedPlayoffMatch(match);
    }

    /**
     * Builds one match from its fields; 'o' is the index of the matchId field
     * (0 for league records, 1 for playoff records). A completed match gets its
     * result RECALCULATED from the saved scores, so the file cannot hold a result
     * that disagrees with the scores.
     */
    private Match buildMatch(String[] f, int o, MatchStage stage) {
        int matchId = parseInt(f[o], "match ID");
        int matchNo = parseInt(f[o + 1], "match number");
        Team home = requireTeam(parseInt(f[o + 2], "home team ID"), "home");
        Team away = requireTeam(parseInt(f[o + 3], "away team ID"), "away");
        LocalDate date = parseDate(f[o + 4]);
        String venue = f[o + 5];
        MatchStatus status = parseStatus(f[o + 6]);

        Match match = new Match(matchId, matchNo, home, away, date, venue, stage);

        if (status == MatchStatus.COMPLETED) {
            Team battingFirst = requireTeam(parseInt(f[o + 7], "batting-first team ID"),
                    "batting-first");
            Innings first = new Innings(parseInt(f[o + 8], "innings 1 runs"),
                    parseInt(f[o + 9], "innings 1 wickets"), parseInt(f[o + 10], "innings 1 balls"));
            Innings second = new Innings(parseInt(f[o + 11], "innings 2 runs"),
                    parseInt(f[o + 12], "innings 2 wickets"), parseInt(f[o + 13], "innings 2 balls"));
            int tieBreakId = parseInt(f[o + 14], "tie-break winner ID");
            Team tieBreakWinner = (tieBreakId == 0) ? null : requireTeam(tieBreakId, "tie-break");

            MatchResult result = ResultCalculator.calculate(
                    match, battingFirst, first, second, tieBreakWinner, settings);
            match.complete(battingFirst, first, second, result);
        } else if (status == MatchStatus.NO_RESULT) {
            match.markNoResult(ResultCalculator.noResult());
        }
        return match;
    }

    private Team requireTeam(int id, String role) {
        Team team = teamManager.findById(id);
        if (team == null) {
            throw new IllegalArgumentException(role + " team ID " + id + " is not a registered team");
        }
        return team;
    }

    // ---- Parsing helpers (all report problems as IllegalArgumentException) ----

    private static String[] splitFields(String line, int expected) {
        String[] f = line.split("\\|", -1);          // -1 keeps empty trailing fields
        if (f.length != expected) {
            throw new IllegalArgumentException("expected " + expected
                    + " fields separated by '|' but found " + f.length);
        }
        for (int i = 0; i < f.length; i++) {
            f[i] = f[i].trim();
        }
        return f;
    }

    private static int parseInt(String text, String fieldName) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(fieldName + " must be a whole number but is '" + text + "'");
        }
    }

    private static boolean parseBoolean(String text, String fieldName) {
        if (text.equals("true")) return true;
        if (text.equals("false")) return false;
        throw new IllegalArgumentException(fieldName + " must be true or false but is '" + text + "'");
    }

    private static LocalDate parseDate(String text) {
        try {
            return LocalDate.parse(text);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("date must be yyyy-MM-dd but is '" + text + "'");
        }
    }

    private static MatchStatus parseStatus(String text) {
        try {
            return MatchStatus.valueOf(text);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("unknown match status '" + text + "'");
        }
    }

    // ==================================================================
    // SAVING
    // ==================================================================

    /**
     * Saves all four files. Every file is first written to a temporary ".tmp" file;
     * only if ALL of them were written successfully are they moved over the real
     * files. A failure while writing therefore never leaves a half-written data file.
     *
     * @throws IOException if a file cannot be written
     */
    public void saveAll() throws IOException {
        Files.createDirectories(dataDir);

        Map<String, List<String>> contents = new LinkedHashMap<>();
        contents.put(SETTINGS_FILE, settingLines());
        contents.put(TEAMS_FILE, teamLines());
        contents.put(MATCHES_FILE, leagueMatchLines());
        contents.put(PLAYOFF_FILE, playoffMatchLines());

        // Step 1: write temporary files
        List<Path> temps = new ArrayList<>();
        try {
            for (Map.Entry<String, List<String>> entry : contents.entrySet()) {
                Path temp = dataDir.resolve(entry.getKey() + ".tmp");
                Files.write(temp, entry.getValue(), StandardCharsets.UTF_8);
                temps.add(temp);
            }
        } catch (IOException e) {
            for (Path temp : temps) {
                try {
                    Files.deleteIfExists(temp);
                } catch (IOException cleanupError) {
                    e.addSuppressed(cleanupError);   // keep the original error, note this one
                }
            }
            throw e;
        }

        // Step 2: move them into place
        int i = 0;
        for (String fileName : contents.keySet()) {
            moveIntoPlace(temps.get(i), dataDir.resolve(fileName));
            i++;
        }
    }

    private static void moveIntoPlace(Path temp, Path target) throws IOException {
        try {
            Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private List<String> settingLines() {
        List<String> lines = new ArrayList<>();
        lines.add("# IPL-style tournament simulation - settings");
        lines.add("# Format: key=value");
        lines.add("pointsForWin=" + settings.getPointsForWin());
        lines.add("pointsForLoss=" + settings.getPointsForLoss());
        lines.add("pointsForTie=" + settings.getPointsForTie());
        lines.add("pointsForNoResult=" + settings.getPointsForNoResult());
        lines.add("maxOvers=" + settings.getMaxOvers());
        lines.add("maxWickets=" + settings.getMaxWickets());
        lines.add("doubleRoundRobin=" + settings.isDoubleRoundRobin());
        lines.add("qualifiersCount=" + settings.getQualifiersCount());
        lines.add("playoffsEnabled=" + settings.isPlayoffsEnabled());
        lines.add("tieBreakInLeague=" + settings.isTieBreakInLeague());
        return lines;
    }

    private List<String> teamLines() {
        List<String> lines = new ArrayList<>();
        lines.add("# IPL-style tournament simulation - teams");
        lines.add("# Format: id|name|shortName|homeCity");
        for (Team t : teamManager.getAllTeams()) {
            lines.add(t.getId() + "|" + t.getName() + "|" + t.getShortName() + "|" + t.getHomeCity());
        }
        return lines;
    }

    private List<String> leagueMatchLines() {
        List<String> lines = new ArrayList<>();
        lines.add("# IPL-style tournament simulation - league matches");
        lines.add("# Format: matchId|matchNo|homeId|awayId|date|venue|status|battingFirstId|"
                + "inn1Runs|inn1Wkts|inn1Balls|inn2Runs|inn2Wkts|inn2Balls|tieBreakWinnerId");
        lines.add("# Innings are in runs, wickets and legal balls (overs x 6 + balls). Results are recalculated on load.");
        for (Match m : matchManager.getAllMatches()) {
            lines.add(matchRecord(m));
        }
        return lines;
    }

    private List<String> playoffMatchLines() {
        List<String> lines = new ArrayList<>();
        lines.add("# IPL-style tournament simulation - playoff matches");
        lines.add("# Format: stage|matchId|matchNo|homeId|awayId|date|venue|status|battingFirstId|"
                + "inn1Runs|inn1Wkts|inn1Balls|inn2Runs|inn2Wkts|inn2Balls|tieBreakWinnerId");
        for (Match m : playoffManager.getPlayoffMatches()) {
            lines.add(m.getStage().name() + "|" + matchRecord(m));
        }
        return lines;
    }

    /** The 15 shared fields of a match record. Unused fields are 0. */
    private String matchRecord(Match m) {
        int battingFirstId = 0;
        Innings first = null;
        Innings second = null;
        int tieBreakId = 0;

        if (m.getStatus() == MatchStatus.COMPLETED) {
            battingFirstId = m.getBattingFirst().getId();
            first = m.getFirstInnings();
            second = m.getSecondInnings();
            if (m.getResult().getMarginType() == MatchResult.MarginType.TIE_BREAK) {
                tieBreakId = m.getWinner().getId();
            }
        }
        return m.getMatchId() + "|" + m.getMatchNumber() + "|"
                + m.getHomeTeam().getId() + "|" + m.getAwayTeam().getId() + "|"
                + m.getMatchDate() + "|" + m.getVenue() + "|" + m.getStatus().name() + "|"
                + battingFirstId + "|"
                + (first == null ? "0|0|0" : first.getRuns() + "|" + first.getWickets() + "|" + first.getBalls()) + "|"
                + (second == null ? "0|0|0" : second.getRuns() + "|" + second.getWickets() + "|" + second.getBalls()) + "|"
                + tieBreakId;
    }
}
