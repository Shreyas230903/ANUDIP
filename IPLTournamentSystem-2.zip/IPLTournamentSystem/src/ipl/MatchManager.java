package ipl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Manages the LEAGUE-stage schedule: creating, validating, generating,
 * searching and filtering matches (Step 4), and score entry, no-result
 * entry and corrections (Step 5). No console input or output.
 * All failures are reported with IllegalArgumentException and a clear message.
 */
public class MatchManager {

    public static final int MAX_VENUE_LENGTH = 24;
    // '|' is excluded because it separates fields in data files
    private static final String VENUE_PATTERN = "[A-Za-z0-9 .,'&-]+";

    private final TeamManager teamManager;
    private final TournamentSettings settings;
    private final List<Match> matches = new ArrayList<>();
    private final List<String> correctionLog = new ArrayList<>();
    private int nextMatchId = 1;
    private int nextMatchNumber = 1;

    public MatchManager(TeamManager teamManager, TournamentSettings settings) {
        this.teamManager = teamManager;
        this.settings = settings;
    }

    // ------------------------------------------------------------------
    // Manual scheduling
    // ------------------------------------------------------------------

    /**
     * Creates a league match between two registered teams.
     *
     * @throws IllegalArgumentException if any rule is broken
     */
    public Match scheduleMatch(int homeTeamId, int awayTeamId, LocalDate date, String venue) {
        Team home = requireTeam(homeTeamId, "Home");
        Team away = requireTeam(awayTeamId, "Away");
        if (home.equals(away)) {
            throw new IllegalArgumentException("A team cannot play against itself.");
        }
        if (date == null) {
            throw new IllegalArgumentException("Match date is required.");
        }
        validateVenue(venue);
        checkFixtureAllowed(home, away);
        checkTeamsFree(home, away, date);

        return addFixture(home, away, date, venue.trim());
    }

    private Team requireTeam(int teamId, String role) {
        Team team = teamManager.findById(teamId);
        if (team == null) {
            throw new IllegalArgumentException(role + " team ID " + teamId
                    + " is not a registered team.");
        }
        return team;
    }

    private void validateVenue(String venue) {
        if (venue == null || venue.trim().isEmpty()) {
            throw new IllegalArgumentException("Venue cannot be empty.");
        }
        if (venue.trim().length() > MAX_VENUE_LENGTH) {
            throw new IllegalArgumentException(
                    "Venue cannot exceed " + MAX_VENUE_LENGTH + " characters.");
        }
        if (!venue.trim().matches(VENUE_PATTERN)) {
            throw new IllegalArgumentException(
                    "Venue may contain only letters, digits, spaces and . , ' & - characters.");
        }
    }

    /** Enforces the fixture limits of the configured format. */
    private void checkFixtureAllowed(Team home, Team away) {
        int meetings = 0;
        for (Match m : matches) {
            if (m.getHomeTeam().equals(home) && m.getAwayTeam().equals(away)) {
                throw new IllegalArgumentException("The fixture " + home.getShortName()
                        + " vs " + away.getShortName()
                        + " is already scheduled as match " + m.getMatchNumber() + ".");
            }
            if (m.involves(home) && m.involves(away)) {
                meetings++;
            }
        }
        int allowed = settings.isDoubleRoundRobin() ? 2 : 1;
        if (meetings >= allowed) {
            throw new IllegalArgumentException(home.getShortName() + " and "
                    + away.getShortName() + " already meet " + meetings
                    + " time(s); the current format allows only " + allowed + ".");
        }
    }

    /** A team cannot play two matches on the same date. */
    private void checkTeamsFree(Team home, Team away, LocalDate date) {
        for (Match m : matches) {
            if (m.getMatchDate().equals(date) && (m.involves(home) || m.involves(away))) {
                throw new IllegalArgumentException("One of these teams already plays on "
                        + date + " (match " + m.getMatchNumber() + ").");
            }
        }
    }

    /** Creates the match object and registers it. All checks must already be done. */
    private Match addFixture(Team home, Team away, LocalDate date, String venue) {
        Match match = new Match(nextMatchId, nextMatchNumber, home, away,
                date, venue, MatchStage.LEAGUE);
        matches.add(match);
        nextMatchId++;
        nextMatchNumber++;
        return match;
    }

    // ------------------------------------------------------------------
    // Automatic round-robin generation
    // ------------------------------------------------------------------

    /**
     * Generates the fixtures that are still missing for the configured format.
     * Single round robin: every pair meets once.
     * Double round robin: every pair meets twice, home and away reversed.
     * Existing matches are kept, so running this twice adds nothing new.
     *
     * @param startDate  date of the first generated match
     * @param gapDays    days between consecutive generated matches (1 to 30)
     * @return number of matches added
     */
    public int generateRoundRobin(LocalDate startDate, int gapDays) {
        if (startDate == null) {
            throw new IllegalArgumentException("Start date is required.");
        }
        if (gapDays < 1 || gapDays > 30) {
            throw new IllegalArgumentException("Days between matches must be 1 to 30.");
        }
        List<Team> teams = teamManager.getAllTeams();
        if (teams.size() < 2) {
            throw new IllegalArgumentException(
                    "At least 2 registered teams are needed to generate a schedule.");
        }

        int legs = settings.isDoubleRoundRobin() ? 2 : 1;
        int added = 0;
        LocalDate nextDate = startDate;

        for (int leg = 1; leg <= legs; leg++) {
            for (int i = 0; i < teams.size(); i++) {
                for (int j = i + 1; j < teams.size(); j++) {
                    // Leg 1: lower index at home. Leg 2: home and away reversed.
                    Team home = (leg == 1) ? teams.get(i) : teams.get(j);
                    Team away = (leg == 1) ? teams.get(j) : teams.get(i);

                    if (!needsFixture(home, away)) {
                        continue;
                    }
                    LocalDate date = findFreeDate(nextDate, home, away);
                    addFixture(home, away, date, home.getHomeCity() + " Stadium");
                    nextDate = date.plusDays(gapDays);
                    added++;
                }
            }
        }
        return added;
    }

    /** True if this home-away fixture is still missing under the current format. */
    private boolean needsFixture(Team home, Team away) {
        for (Match m : matches) {
            if (m.getHomeTeam().equals(home) && m.getAwayTeam().equals(away)) {
                return false;   // exactly this fixture exists
            }
            // Single round robin: either direction counts as the one meeting
            if (!settings.isDoubleRoundRobin() && m.involves(home) && m.involves(away)) {
                return false;
            }
        }
        return true;
    }

    /** First date on or after 'from' on which neither team plays. */
    private LocalDate findFreeDate(LocalDate from, Team home, Team away) {
        LocalDate date = from;
        while (isTeamBusy(home, date) || isTeamBusy(away, date)) {
            date = date.plusDays(1);
        }
        return date;
    }

    private boolean isTeamBusy(Team team, LocalDate date) {
        for (Match m : matches) {
            if (m.getMatchDate().equals(date) && m.involves(team)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------
    // Score entry, results and corrections (Step 5)
    // ------------------------------------------------------------------

    /**
     * Enters the scores of a SCHEDULED match and stores the calculated result.
     * A match that is already COMPLETED or NO_RESULT is refused: use
     * correctScore() instead, which is the explicit correction process.
     *
     * @param battingFirstTeamId team that batted first (must be in this match)
     * @param first              innings of the team that batted first
     * @param second             innings of the team that batted second
     * @param tieBreakWinnerId   tie-break winner's team ID, or 0 if there was none
     * @return the updated match
     * @throws IllegalArgumentException if the match is unknown, already finished,
     *                                  or the scores break a rule
     */
    public Match enterScore(int matchId, int battingFirstTeamId, Innings first,
                            Innings second, int tieBreakWinnerId) {
        Match match = requireMatch(matchId);
        if (match.isFinished()) {
            throw new IllegalArgumentException("Match " + match.getMatchNumber()
                    + " already has a result (" + match.getResultDescription()
                    + "). It cannot be overwritten; use the correction process.");
        }
        applyScore(match, battingFirstTeamId, first, second, tieBreakWinnerId);
        return match;
    }

    /**
     * Marks a SCHEDULED match as having no result (abandoned).
     * No winner is declared and no innings are stored.
     */
    public Match enterNoResult(int matchId) {
        Match match = requireMatch(matchId);
        if (match.isFinished()) {
            throw new IllegalArgumentException("Match " + match.getMatchNumber()
                    + " already has a result (" + match.getResultDescription()
                    + "). It cannot be overwritten; use the correction process.");
        }
        requireRegisteredTeams(match);
        match.markNoResult(ResultCalculator.noResult());
        return match;
    }

    /**
     * Correction process: replaces the result of a finished match with new scores.
     * The old data is REPLACED, not added to. Because the points table is always
     * recalculated from the match records (Step 6), nothing is counted twice.
     * If the new data is invalid, the old result stays untouched.
     */
    public Match correctScore(int matchId, int battingFirstTeamId, Innings first,
                              Innings second, int tieBreakWinnerId) {
        Match match = requireMatch(matchId);
        requireFinished(match);
        String before = match.getResultDescription();
        applyScore(match, battingFirstTeamId, first, second, tieBreakWinnerId);
        logCorrection(match, before);
        return match;
    }

    /** Correction process: changes a finished match to "no result". */
    public Match correctToNoResult(int matchId) {
        Match match = requireMatch(matchId);
        requireFinished(match);
        String before = match.getResultDescription();
        requireRegisteredTeams(match);
        match.markNoResult(ResultCalculator.noResult());
        logCorrection(match, before);
        return match;
    }

    /**
     * Correction process: removes a result entered by mistake, returning the
     * match to SCHEDULED so it can be entered again with enterScore().
     */
    public Match reopenMatch(int matchId) {
        Match match = requireMatch(matchId);
        requireFinished(match);
        String before = match.getResultDescription();
        match.reset();
        logCorrection(match, before);
        return match;
    }

    /**
     * Removes every league match and restarts match numbering, for a new season.
     * Teams are not touched. The caller must ask for confirmation.
     *
     * @return the number of matches removed
     */
    public int clearAllMatches() {
        int removed = matches.size();
        matches.clear();
        correctionLog.clear();
        nextMatchId = 1;
        nextMatchNumber = 1;
        return removed;
    }

    /** Read-only list of the corrections made in this session. */
    public List<String> getCorrectionLog() {
        return Collections.unmodifiableList(correctionLog);
    }

    /** Validates, calculates and stores a result. The match changes only if all checks pass. */
    private void applyScore(Match match, int battingFirstTeamId, Innings first,
                            Innings second, int tieBreakWinnerId) {
        requireRegisteredTeams(match);

        Team battingFirst = teamManager.findById(battingFirstTeamId);
        if (battingFirst == null || !match.involves(battingFirst)) {
            throw new IllegalArgumentException("Team ID " + battingFirstTeamId
                    + " is not one of the two teams in match " + match.getMatchNumber() + ".");
        }
        Team tieBreakWinner = null;
        if (tieBreakWinnerId > 0) {
            tieBreakWinner = teamManager.findById(tieBreakWinnerId);
            if (tieBreakWinner == null) {
                throw new IllegalArgumentException(
                        "Tie-break team ID " + tieBreakWinnerId + " is not a registered team.");
            }
        }

        // Throws IllegalArgumentException before anything is changed
        MatchResult result = ResultCalculator.calculate(
                match, battingFirst, first, second, tieBreakWinner, settings);
        match.complete(battingFirst, first, second, result);
    }

    private Match requireMatch(int matchId) {
        Match match = findById(matchId);
        if (match == null) {
            throw new IllegalArgumentException("No league match with ID " + matchId + ".");
        }
        return match;
    }

    private void requireFinished(Match match) {
        if (!match.isFinished()) {
            throw new IllegalArgumentException("Match " + match.getMatchNumber()
                    + " has no result yet. Use normal score entry instead of a correction.");
        }
    }

    /** Both teams of the match must still be registered. */
    private void requireRegisteredTeams(Match match) {
        if (teamManager.findById(match.getHomeTeam().getId()) == null
                || teamManager.findById(match.getAwayTeam().getId()) == null) {
            throw new IllegalArgumentException("Match " + match.getMatchNumber()
                    + " refers to a team that is not registered.");
        }
    }

    private void logCorrection(Match match, String before) {
        correctionLog.add("Match " + match.getMatchNumber() + " corrected: ["
                + before + "] -> [" + match.getResultDescription() + "]");
    }

    // ------------------------------------------------------------------
    // Search and filtering
    // ------------------------------------------------------------------

    /** @return the match with this ID, or null */
    public Match findById(int matchId) {
        for (Match m : matches) {
            if (m.getMatchId() == matchId) {
                return m;
            }
        }
        return null;
    }

    /** All matches in which the team plays, in schedule order. */
    public List<Match> getMatchesForTeam(Team team) {
        List<Match> result = new ArrayList<>();
        for (Match m : matches) {
            if (m.involves(team)) {
                result.add(m);
            }
        }
        return result;
    }

    /**
     * Matches of every team found by TeamManager.search() (ID, name or short name).
     * Each match appears at most once.
     */
    public List<Match> findByTeamKeyword(String keyword) {
        List<Team> found = teamManager.search(keyword);
        List<Match> result = new ArrayList<>();
        for (Match m : matches) {
            for (Team t : found) {
                if (m.involves(t)) {
                    result.add(m);
                    break;   // do not add the same match twice
                }
            }
        }
        return result;
    }

    /** Matches that have not been played yet. */
    public List<Match> getUpcomingMatches() {
        List<Match> result = new ArrayList<>();
        for (Match m : matches) {
            if (m.isScheduled()) {
                result.add(m);
            }
        }
        return result;
    }

    /** Matches that are COMPLETED or NO_RESULT. */
    public List<Match> getFinishedMatches() {
        List<Match> result = new ArrayList<>();
        for (Match m : matches) {
            if (m.isFinished()) {
                result.add(m);
            }
        }
        return result;
    }

    /** True when at least one match exists and none is still SCHEDULED. */
    public boolean isLeagueStageComplete() {
        return !matches.isEmpty() && getUpcomingMatches().isEmpty();
    }

    // ------------------------------------------------------------------
    // Access and loading
    // ------------------------------------------------------------------

    /** Read-only view of the full schedule, in match-number order. */
    public List<Match> getAllMatches() {
        return Collections.unmodifiableList(matches);
    }

    public int getMatchCount() {
        return matches.size();
    }

    /**
     * Adds a match read from a data file (used by FileManager in Step 9).
     * Rejects duplicate IDs or numbers, unregistered teams and non-league matches.
     */
    public void addLoadedMatch(Match match) {
        if (match == null) {
            throw new IllegalArgumentException("Match record is missing.");
        }
        if (match.getStage() != MatchStage.LEAGUE) {
            throw new IllegalArgumentException("Only league matches belong in the league schedule.");
        }
        if (teamManager.findById(match.getHomeTeam().getId()) == null
                || teamManager.findById(match.getAwayTeam().getId()) == null) {
            throw new IllegalArgumentException("Match " + match.getMatchId()
                    + " refers to a team that is not registered.");
        }
        for (Match m : matches) {
            if (m.getMatchId() == match.getMatchId()) {
                throw new IllegalArgumentException(
                        "Match ID " + match.getMatchId() + " already exists.");
            }
            if (m.getMatchNumber() == match.getMatchNumber()) {
                throw new IllegalArgumentException(
                        "Match number " + match.getMatchNumber() + " already exists.");
            }
            if (m.getHomeTeam().equals(match.getHomeTeam())
                    && m.getAwayTeam().equals(match.getAwayTeam())) {
                throw new IllegalArgumentException("The fixture " + match.getHomeTeam().getShortName()
                        + " vs " + match.getAwayTeam().getShortName()
                        + " already exists as match " + m.getMatchNumber() + ".");
            }
        }
        matches.add(match);
        matches.sort(Comparator.comparingInt(Match::getMatchNumber));
        if (match.getMatchId() >= nextMatchId) {
            nextMatchId = match.getMatchId() + 1;
        }
        if (match.getMatchNumber() >= nextMatchNumber) {
            nextMatchNumber = match.getMatchNumber() + 1;
        }
    }
}
