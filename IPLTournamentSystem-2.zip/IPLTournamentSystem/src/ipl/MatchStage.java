package ipl;

/**
 * Stage of the tournament a match belongs to.
 * League matches affect the points table; playoff matches do not.
 */
public enum MatchStage {
    LEAGUE("League Match"),
    QUALIFIER_1("Qualifier 1"),
    ELIMINATOR("Eliminator"),
    QUALIFIER_2("Qualifier 2"),
    FINAL("Final");

    private final String label;

    MatchStage(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }

    /** Returns true for any stage other than LEAGUE. */
    public boolean isPlayoff() {
        return this != LEAGUE;
    }

    @Override
    public String toString() {
        return label;
    }
}
