package ipl;

import java.io.IOException;
import java.time.LocalDate;

/**
 * Holds the whole tournament (settings, teams, matches, points table, playoffs,
 * files) and applies the rules that cut ACROSS modules. No console input or output.
 *
 * Cross-module rules enforced here:
 *  1. Once the playoffs have started, league data is LOCKED: no new teams, no
 *     new league matches, no score entry or correction, and no change to the
 *     points or qualification settings. Otherwise a change could alter who
 *     qualified after the fixtures were already created.
 *     (Reset the playoffs first if a change is really needed.)
 *  2. The scoring rules (overs per innings, maximum wickets, league tie-break)
 *     cannot change once any match has a result, because saved scores would
 *     no longer be valid under the new rules.
 *  3. A new season clears all matches and playoffs and zeroes team statistics,
 *     but keeps the teams and the settings.
 *
 * All failures are reported with IllegalArgumentException and a clear message.
 */
public class TournamentManager {

    private final TournamentSettings settings = new TournamentSettings();
    private final TeamManager teamManager = new TeamManager();
    private final MatchManager matchManager;
    private final PointsTable pointsTable;
    private final PlayoffManager playoffManager;
    private final FileManager fileManager;
    private final String dataDirectory;

    public TournamentManager(String dataDirectory) {
        this.dataDirectory = dataDirectory;
        this.matchManager = new MatchManager(teamManager, settings);
        this.pointsTable = new PointsTable(teamManager, matchManager, settings);
        this.playoffManager = new PlayoffManager(teamManager, matchManager, pointsTable, settings);
        this.fileManager = new FileManager(dataDirectory, teamManager, matchManager,
                playoffManager, pointsTable, settings);
    }

    // ---- Access to the parts ----
    public TournamentSettings getSettings()  { return settings; }
    public TeamManager getTeamManager()      { return teamManager; }
    public MatchManager getMatchManager()    { return matchManager; }
    public PointsTable getPointsTable()      { return pointsTable; }
    public PlayoffManager getPlayoffManager(){ return playoffManager; }
    public String getDataDirectory()         { return dataDirectory; }

    // ---- Files ----

    /** Loads saved data (see FileManager). Call once, at start-up. */
    public FileManager.LoadResult loadSavedData() {
        return fileManager.loadAll();
    }

    /** Saves everything. @throws IOException if a file cannot be written */
    public void saveData() throws IOException {
        fileManager.saveAll();
    }

    // ---- Locks ----

    /** True once the playoff fixtures exist. */
    public boolean isLeagueLocked() {
        return playoffManager.hasStarted();
    }

    private void requireLeagueUnlocked() {
        if (isLeagueLocked()) {
            throw new IllegalArgumentException("The playoffs have started, so league data can no "
                    + "longer be changed. If you really must change it, reset the playoffs first "
                    + "(menu option 13).");
        }
    }

    private void requireNoResultsYet() {
        requireLeagueUnlocked();
        if (!matchManager.getFinishedMatches().isEmpty()) {
            throw new IllegalArgumentException("Scoring rules cannot be changed after match "
                    + "results have been entered. Start a new season first (option 4, then 4).");
        }
    }

    // ---- Teams and league matches (all respect the lock) ----

    public Team registerTeam(String name, String shortName, String city) {
        requireLeagueUnlocked();
        return teamManager.registerTeam(name, shortName, city);
    }

    public Match scheduleMatch(int homeId, int awayId, LocalDate date, String venue) {
        requireLeagueUnlocked();
        return matchManager.scheduleMatch(homeId, awayId, date, venue);
    }

    public int generateRoundRobin(LocalDate startDate, int gapDays) {
        requireLeagueUnlocked();
        return matchManager.generateRoundRobin(startDate, gapDays);
    }

    public Match enterScore(int matchId, int battingFirstTeamId, Innings first,
                            Innings second, int tieBreakWinnerId) {
        requireLeagueUnlocked();
        return matchManager.enterScore(matchId, battingFirstTeamId, first, second, tieBreakWinnerId);
    }

    public Match enterNoResult(int matchId) {
        requireLeagueUnlocked();
        return matchManager.enterNoResult(matchId);
    }

    public Match correctScore(int matchId, int battingFirstTeamId, Innings first,
                              Innings second, int tieBreakWinnerId) {
        requireLeagueUnlocked();
        return matchManager.correctScore(matchId, battingFirstTeamId, first, second, tieBreakWinnerId);
    }

    public Match correctToNoResult(int matchId) {
        requireLeagueUnlocked();
        return matchManager.correctToNoResult(matchId);
    }

    public Match reopenMatch(int matchId) {
        requireLeagueUnlocked();
        return matchManager.reopenMatch(matchId);
    }

    // ---- Settings ----

    /** Changes the points system. Standings are rebuilt automatically from the matches. */
    public void setPoints(int win, int loss, int tie, int noResult) {
        requireLeagueUnlocked();
        settings.setPointsForWin(win);
        settings.setPointsForLoss(loss);
        settings.setPointsForTie(tie);
        settings.setPointsForNoResult(noResult);
        pointsTable.recalculate();
    }

    public void setDoubleRoundRobin(boolean value) {
        requireLeagueUnlocked();
        settings.setDoubleRoundRobin(value);
    }

    public void setMaxOvers(int overs) {
        requireNoResultsYet();
        settings.setMaxOvers(overs);
    }

    public void setMaxWickets(int wickets) {
        requireNoResultsYet();
        settings.setMaxWickets(wickets);
    }

    public void setTieBreakInLeague(boolean value) {
        requireNoResultsYet();
        settings.setTieBreakInLeague(value);
    }

    public void setQualifiersCount(int count) {
        requireLeagueUnlocked();
        settings.setQualifiersCount(count);
    }

    public void setPlayoffsEnabled(boolean value) {
        requireLeagueUnlocked();
        settings.setPlayoffsEnabled(value);
    }

    // ---- New season ----

    /**
     * Starts a genuinely new season: removes all league and playoff matches and
     * zeroes the team statistics. Teams and settings are kept.
     * The caller must ask for confirmation first.
     */
    public void startNewSeason() {
        playoffManager.resetPlayoffs();
        matchManager.clearAllMatches();
        teamManager.resetSeasonStatistics();
        pointsTable.recalculate();
    }

    // ---- Status ----

    /** One line shown above the main menu. */
    public String getStatusLine() {
        int total = matchManager.getMatchCount();
        int finished = matchManager.getFinishedMatches().size();
        String playoffs;
        if (!playoffManager.hasStarted()) {
            playoffs = "not started";
        } else if (playoffManager.isFinished()) {
            playoffs = "finished";
        } else {
            playoffs = "in progress";
        }
        return "Teams: " + teamManager.getTeamCount() + " | League matches: " + total
                + " (" + finished + " finished) | Playoffs: " + playoffs;
    }
}
