package ipl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Manages the list of registered teams: registration, validation,
 * duplicate prevention and searching.
 * This class does no console input or output.
 */
public class TeamManager {

    // ---- Validation limits (match the column widths in Team.toRow()) ----
    public static final int MAX_NAME_LENGTH = 28;
    public static final int MAX_CITY_LENGTH = 14;
    public static final int MIN_SHORT_LENGTH = 2;
    public static final int MAX_SHORT_LENGTH = 5;

    // The '|' character is excluded because it separates fields in data files.
    private static final String NAME_PATTERN = "[A-Za-z0-9 .'&-]+";
    private static final String CITY_PATTERN = "[A-Za-z .'-]+";
    private static final String SHORT_NAME_PATTERN = "[A-Za-z]+";

    private final List<Team> teams = new ArrayList<>();
    private int nextId = 1;

    // ------------------------------------------------------------------
    // Registration
    // ------------------------------------------------------------------

    /**
     * Registers a new team and assigns it the next unique ID.
     *
     * @throws IllegalArgumentException if any field is invalid or duplicated
     */
    public Team registerTeam(String name, String shortName, String homeCity) {
        validateFields(name, shortName, homeCity);
        checkDuplicates(nextId, name.trim(), shortName.trim());

        Team team = new Team(nextId, name, shortName, homeCity);
        teams.add(team);
        nextId++;
        return team;
    }

    /**
     * Adds a team read from a data file, keeping its saved ID.
     * Used by FileManager. Applies the same checks as registerTeam().
     *
     * @throws IllegalArgumentException if the team is invalid or a duplicate
     */
    public void addLoadedTeam(Team team) {
        if (team == null) {
            throw new IllegalArgumentException("Team record is missing.");
        }
        validateFields(team.getName(), team.getShortName(), team.getHomeCity());
        checkDuplicates(team.getId(), team.getName(), team.getShortName());

        teams.add(team);
        // Keep the list ordered by ID, whatever order the file used
        teams.sort(Comparator.comparingInt(Team::getId));
        // Make sure newly registered teams never reuse a loaded ID
        if (team.getId() >= nextId) {
            nextId = team.getId() + 1;
        }
    }

    // ------------------------------------------------------------------
    // Validation
    // ------------------------------------------------------------------

    /** Checks the three text fields. Throws a descriptive exception if invalid. */
    private void validateFields(String name, String shortName, String homeCity) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Team name cannot be empty.");
        }
        if (name.trim().length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(
                    "Team name cannot exceed " + MAX_NAME_LENGTH + " characters.");
        }
        if (!name.trim().matches(NAME_PATTERN)) {
            throw new IllegalArgumentException(
                    "Team name may contain only letters, digits, spaces and . ' & - characters.");
        }

        if (shortName == null || shortName.trim().isEmpty()) {
            throw new IllegalArgumentException("Short name cannot be empty.");
        }
        String sn = shortName.trim();
        if (sn.length() < MIN_SHORT_LENGTH || sn.length() > MAX_SHORT_LENGTH) {
            throw new IllegalArgumentException("Short name must be "
                    + MIN_SHORT_LENGTH + " to " + MAX_SHORT_LENGTH + " letters long.");
        }
        if (!sn.matches(SHORT_NAME_PATTERN)) {
            throw new IllegalArgumentException("Short name may contain letters only.");
        }

        if (homeCity == null || homeCity.trim().isEmpty()) {
            throw new IllegalArgumentException("Home city cannot be empty.");
        }
        if (homeCity.trim().length() > MAX_CITY_LENGTH) {
            throw new IllegalArgumentException(
                    "Home city cannot exceed " + MAX_CITY_LENGTH + " characters.");
        }
        if (!homeCity.trim().matches(CITY_PATTERN)) {
            throw new IllegalArgumentException(
                    "Home city may contain only letters, spaces and . ' - characters.");
        }
    }

    /** Rejects a duplicate ID, short name or team name (case-insensitive). */
    private void checkDuplicates(int id, String name, String shortName) {
        for (Team t : teams) {
            if (t.getId() == id) {
                throw new IllegalArgumentException("Team ID " + id + " already exists.");
            }
            if (t.getShortName().equalsIgnoreCase(shortName)) {
                throw new IllegalArgumentException("Short name '"
                        + shortName.toUpperCase() + "' is already used by " + t.getName() + ".");
            }
            if (t.getName().equalsIgnoreCase(name)) {
                throw new IllegalArgumentException(
                        "A team named '" + t.getName() + "' is already registered.");
            }
        }
    }

    // ------------------------------------------------------------------
    // Lookup and search
    // ------------------------------------------------------------------

    /** @return the team with this ID, or null if none exists */
    public Team findById(int id) {
        for (Team t : teams) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    /** Exact, case-insensitive match. @return the team or null */
    public Team findByShortName(String shortName) {
        if (shortName == null) return null;
        for (Team t : teams) {
            if (t.getShortName().equalsIgnoreCase(shortName.trim())) {
                return t;
            }
        }
        return null;
    }

    /** Exact, case-insensitive match. @return the team or null */
    public Team findByName(String name) {
        if (name == null) return null;
        for (Team t : teams) {
            if (t.getName().equalsIgnoreCase(name.trim())) {
                return t;
            }
        }
        return null;
    }

    /**
     * Searches by ID (if the keyword is a number), or by part of the
     * team name or short name. Case-insensitive.
     * Each team appears at most once in the result.
     *
     * @return matching teams; an empty list if the keyword is blank or nothing matches
     */
    public List<Team> search(String keyword) {
        List<Team> results = new ArrayList<>();
        if (keyword == null) {
            return results;
        }
        String key = keyword.trim().toLowerCase();
        if (key.isEmpty()) {
            return results;
        }

        // Treat short all-digit keywords as IDs (limit avoids int overflow)
        boolean numeric = key.matches("\\d{1,9}");
        int idValue = numeric ? Integer.parseInt(key) : -1;

        for (Team t : teams) {
            boolean match = (numeric && t.getId() == idValue)
                    || t.getName().toLowerCase().contains(key)
                    || t.getShortName().toLowerCase().contains(key);
            if (match) {
                results.add(t);
            }
        }
        return results;
    }

    // ------------------------------------------------------------------
    // Access and season reset
    // ------------------------------------------------------------------

    /** Read-only view of all teams, ordered by ID. */
    public List<Team> getAllTeams() {
        return Collections.unmodifiableList(teams);
    }

    public int getTeamCount() {
        return teams.size();
    }

    public boolean isEmpty() {
        return teams.isEmpty();
    }

    /**
     * Sets every team's season statistics back to zero.
     * Teams themselves are kept. For a full new season,
     * TournamentManager also clears all matches (Step 10).
     */
    public void resetSeasonStatistics() {
        for (Team t : teams) {
            t.resetStatistics();
        }
    }
}
