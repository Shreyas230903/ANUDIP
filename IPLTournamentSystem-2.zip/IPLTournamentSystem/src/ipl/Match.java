package ipl;

import java.time.LocalDate;

/**
 * One match between two teams.
 * Identity data (IDs, teams, date, venue, stage) is fixed at creation.
 * Result data (status, innings, result) can only be changed through the
 * package-private methods complete(), markNoResult() and reset(),
 * which are used by MatchManager (and PlayoffManager in Step 8).
 */
public class Match {

    // ---- Fixed data ----
    private final int matchId;       // unique ID
    private final int matchNumber;   // position in the schedule
    private final Team homeTeam;
    private final Team awayTeam;
    private final LocalDate matchDate;
    private final String venue;
    private final MatchStage stage;

    // ---- Result data ----
    private MatchStatus status = MatchStatus.SCHEDULED;
    private Team battingFirst;       // null until the match is completed
    private Innings firstInnings;    // innings of battingFirst
    private Innings secondInnings;   // innings of the other team
    private MatchResult result;      // null until the match is completed

    public Match(int matchId, int matchNumber, Team homeTeam, Team awayTeam,
                 LocalDate matchDate, String venue, MatchStage stage) {
        if (matchId <= 0 || matchNumber <= 0) {
            throw new IllegalArgumentException("Match ID and match number must be positive.");
        }
        if (homeTeam == null || awayTeam == null) {
            throw new IllegalArgumentException("Both teams are required.");
        }
        if (homeTeam.equals(awayTeam)) {
            throw new IllegalArgumentException("A team cannot play against itself.");
        }
        if (matchDate == null) {
            throw new IllegalArgumentException("Match date is required.");
        }
        if (venue == null || venue.trim().isEmpty()) {
            throw new IllegalArgumentException("Venue cannot be empty.");
        }
        if (stage == null) {
            throw new IllegalArgumentException("Match stage is required.");
        }
        this.matchId = matchId;
        this.matchNumber = matchNumber;
        this.homeTeam = homeTeam;
        this.awayTeam = awayTeam;
        this.matchDate = matchDate;
        this.venue = venue.trim();
        this.stage = stage;
    }

    // ---- Getters ----
    public int getMatchId()          { return matchId; }
    public int getMatchNumber()      { return matchNumber; }
    public Team getHomeTeam()        { return homeTeam; }
    public Team getAwayTeam()        { return awayTeam; }
    public LocalDate getMatchDate()  { return matchDate; }
    public String getVenue()         { return venue; }
    public MatchStage getStage()     { return stage; }
    public MatchStatus getStatus()   { return status; }
    public Innings getFirstInnings() { return firstInnings; }
    public Innings getSecondInnings(){ return secondInnings; }
    public MatchResult getResult()   { return result; }
    public Team getBattingFirst()    { return battingFirst; }

    /** The team that batted second, or null if the match is not completed. */
    public Team getBattingSecond() {
        if (battingFirst == null) return null;
        return battingFirst.equals(homeTeam) ? awayTeam : homeTeam;
    }

    /** The innings played by the given team, or null if there is none. */
    public Innings getInningsFor(Team team) {
        if (team == null || battingFirst == null) return null;
        if (team.equals(battingFirst)) return firstInnings;
        if (team.equals(getBattingSecond())) return secondInnings;
        return null;
    }

    /** The winner, or null for a tie, no result, or an unplayed match. */
    public Team getWinner() {
        return (result == null) ? null : result.getWinner();
    }

    public String getResultDescription() {
        return (result == null) ? "Not played yet" : result.getDescription();
    }

    /** Overs played in cricket notation, e.g. "20.0 / 19.4". */
    public String getOversPlayedText() {
        if (firstInnings == null) return "-";
        String text = firstInnings.getOversText();
        if (secondInnings != null) {
            text += " / " + secondInnings.getOversText();
        }
        return text;
    }

    // ---- Queries ----
    public boolean involves(Team team) {
        return team != null && (homeTeam.equals(team) || awayTeam.equals(team));
    }

    public boolean isScheduled() {
        return status == MatchStatus.SCHEDULED;
    }

    /** True for COMPLETED and NO_RESULT matches. */
    public boolean isFinished() {
        return status != MatchStatus.SCHEDULED;
    }

    // ---- Result changes (package-private) ----

    /**
     * Stores the scores and result of a played match.
     * Validates its arguments but does not calculate the result
     * (ResultCalculator does that).
     */
    void complete(Team battingFirst, Innings first, Innings second, MatchResult result) {
        if (battingFirst == null || !involves(battingFirst)) {
            throw new IllegalArgumentException(
                    "The team batting first must be one of the two teams in this match.");
        }
        if (first == null || second == null) {
            throw new IllegalArgumentException("Both innings are required for a completed match.");
        }
        if (result == null) {
            throw new IllegalArgumentException("A result is required for a completed match.");
        }
        if (result.getType() == MatchResult.Type.NO_RESULT) {
            throw new IllegalArgumentException("Use markNoResult() for a match with no result.");
        }
        if (result.hasWinner() && !involves(result.getWinner())) {
            throw new IllegalArgumentException(
                    "The winner must be one of the two teams in this match.");
        }
        this.battingFirst = battingFirst;
        this.firstInnings = first;
        this.secondInnings = second;
        this.result = result;
        this.status = MatchStatus.COMPLETED;
    }

    /** Marks the match as abandoned. No winner and no innings are stored. */
    void markNoResult(MatchResult result) {
        if (result == null || result.getType() != MatchResult.Type.NO_RESULT) {
            throw new IllegalArgumentException("A NO_RESULT outcome is required.");
        }
        this.battingFirst = null;
        this.firstInnings = null;
        this.secondInnings = null;
        this.result = result;
        this.status = MatchStatus.NO_RESULT;
    }

    /** Returns the match to SCHEDULED, clearing all result data. */
    void reset() {
        this.battingFirst = null;
        this.firstInnings = null;
        this.secondInnings = null;
        this.result = null;
        this.status = MatchStatus.SCHEDULED;
    }

    // ---- Display ----

    /** One table row, matching ReportManager.printMatchList(). */
    public String toRow() {
        return String.format("%-4d %-4d %-10s %-14s %-24s %-10s",
                matchNumber, matchId, matchDate,
                homeTeam.getShortName() + " vs " + awayTeam.getShortName(),
                venue, status.name());
    }

    @Override
    public String toString() {
        return "Match " + matchNumber + " (" + stage + "): " + homeTeam + " vs " + awayTeam
                + " on " + matchDate + " at " + venue + " [" + status + "]";
    }
}
