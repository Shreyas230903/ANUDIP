package ipl;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Safe console input. Every method keeps asking until the user
 * enters a valid value, so bad input can never crash the program.
 * One shared Scanner is used for the whole application.
 */
public class InputHelper {

    private static final Scanner scanner = new Scanner(System.in);

    /** Reads one trimmed line of text (may be empty). */
    public static String readLine(String prompt) {
        System.out.print(prompt);
        try {
            return scanner.nextLine().trim();
        } catch (NoSuchElementException e) {
            // Happens if the input stream is closed (e.g. Ctrl+D)
            throw new IllegalStateException("Input stream closed.", e);
        }
    }

    /** Reads a non-empty line of text. */
    public static String readNonEmpty(String prompt) {
        while (true) {
            String text = readLine(prompt);
            if (!text.isEmpty()) {
                return text;
            }
            System.out.println("Error: input cannot be empty. Please try again.");
        }
    }

    /** Reads an integer between min and max (inclusive). */
    public static int readInt(String prompt, int min, int max) {
        while (true) {
            String text = readLine(prompt);
            try {
                int value = Integer.parseInt(text);
                if (value < min || value > max) {
                    System.out.println("Error: enter a number between "
                            + min + " and " + max + ".");
                } else {
                    return value;
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: '" + text + "' is not a valid whole number.");
            }
        }
    }

    /** Reads a date in yyyy-MM-dd format, e.g. 2026-04-15. */
    public static LocalDate readDate(String prompt) {
        while (true) {
            String text = readLine(prompt);
            try {
                return LocalDate.parse(text);
            } catch (DateTimeParseException e) {
                System.out.println("Error: use the format yyyy-MM-dd (e.g. 2026-04-15).");
            }
        }
    }

    /** Reads a yes/no answer. Accepts y, yes, n, no (any case). */
    public static boolean readYesNo(String prompt) {
        while (true) {
            String text = readLine(prompt + " (y/n): ").toLowerCase();
            if (text.equals("y") || text.equals("yes")) return true;
            if (text.equals("n") || text.equals("no")) return false;
            System.out.println("Error: please answer y or n.");
        }
    }
}
