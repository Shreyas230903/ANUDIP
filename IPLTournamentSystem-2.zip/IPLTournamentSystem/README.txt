IPL-STYLE TOURNAMENT MANAGEMENT SYSTEM (Core Java, console)
===========================================================
A tournament SIMULATION with simplified rules. It is not the official IPL
system and contains no real match data or results.

The data/ folder starts with 10 sample teams (RCB, CSK, PBKS, RR, SRH, GT,
LSG, MI, KKR, DC) and no matches. Their names are used only as sample teams.
To use different teams, edit data/teams.txt before starting, or delete the
four files in data/ to start empty and register teams with menu option 1.

REQUIREMENTS   JDK 8 or later (javac and java). No other software.

COMPILE        Linux/macOS: ./compile.sh      Windows: compile.bat
               Manual: javac -d bin src/ipl/*.java

RUN            Linux/macOS: ./run.sh          Windows: run.bat
               Manual: java -cp bin ipl.Main [data-folder]

QUICK START    Menu 4 > 2  generate a round-robin schedule
               Menu 6 > 1  enter match scores
               Menu 9      points table      Menu 13  playoffs
               Menu 16     save (Exit also saves)

FOLDERS        src/ipl/  source code     data/  saved data (4 text files)
               bin/      compiled classes (created by the compile script)
